import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { writeFileSync, readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
const root = '/root/dev/work/tbt/RapidRAW';
const require = createRequire(`${root}/package.json`);
const { build } = require('esbuild');
const baselineSource = execFileSync('git', ['show', '33ba1eb7:src/store/useUIStore.ts'], { cwd: root, encoding: 'utf8' });
async function bundle(name, baseline = false) {
  const output = `/tmp/task4-store-${name}.cjs`;
  await build({
    stdin: { contents: `export * from './src/store/useUIStore'; export {useEditorStore} from './src/store/useEditorStore'; export {useSettingsStore} from './src/store/useSettingsStore'; export {Panel} from './src/components/ui/AppProperties'; export {INITIAL_ADJUSTMENTS, pickCropGeometry} from './src/utils/adjustments';`, resolveDir: root },
    outfile: output, bundle: true, platform: 'node', format: 'cjs', logLevel: 'silent',
    plugins: [{ name: 'host-only-mocks', setup(b) {
      b.onResolve({ filter: /^(@tauri-apps\/api\/core|@tauri-apps\/plugin-os|react-toastify)$/ }, a => ({ path: a.path, namespace: 'host' }));
      b.onLoad({ filter: /.*/, namespace: 'host' }, a => ({ contents: a.path === 'i18next' ? 'export default { t: key => key };' : a.path === 'react-toastify' ? 'export const toast = {error:()=>{}};' : a.path.endsWith('plugin-os') ? 'export const platform=()=>"linux";' : 'export const invoke=()=>Promise.resolve();' }));
      if (baseline) b.onLoad({ filter: /\/src\/store\/useUIStore\.ts$/ }, () => ({ contents: baselineSource, loader: 'ts', resolveDir: `${root}/src/store` }));
    }}],
  });
  return require(output);
}
const current = await bundle('current');
const old = await bundle('baseline', true);
const { Panel: P } = current;
const tools = [P.Crop, P.Masks, P.Ai];
const regions = ['leftTop', 'leftBottom', 'rightTop', 'rightBottom'];
const allPanels = Object.values(P);
const results = [];
function test(name, fn) {
  try { fn(); results.push({name, pass:true}); }
  catch (error) { results.push({name, pass:false, error:error.stack}); console.error('FAIL', name, error.message); }
}
const initial = new Map([current, old].map(m => [m, { ui:m.useUIStore.getState(), editor:m.useEditorStore.getState(), settings:m.useSettingsStore.getState() }]));
function reset(m=current, platform='linux', full=true, selected=true, workspace) {
  const i=initial.get(m);
  m.useSettingsStore.setState({...i.settings, osPlatform:platform}, true);
  m.useEditorStore.setState({...i.editor, selectedImage:selected ? {path:'/isolated/image.jpg',isReady:true,width:1000,height:800} : null}, true);
  m.useUIStore.setState({...i.ui, isFullLayout:full, activeView:'editor'},true);
  // Exercise the same reconciliation + setUI initialization interface as useAppInitialization.
  m.useUIStore.getState().setUI(m.reconcileWorkspace(workspace,true,platform,full));
}
function snapshot(m) {
  const s=m.useUIStore.getState();
  return JSON.parse(JSON.stringify(Object.fromEntries(Object.entries(s).filter(([,v])=>typeof v!=='function'))));
}
const nasty = {
  leftPanelWidth:173,rightPanelWidth:487,leftTopHeight:289,rightTopHeight:777,
  panelLayout:{leftTop:[P.Crop,P.Presets,P.Crop,'unknown'],leftBottom:[P.Adjustments,P.Metadata],rightTop:[P.Masks,P.FolderTree],rightBottom:[P.Curves,P.Ai,P.Export,P.Tethering]},
  activePanels:{leftTop:P.Crop,leftBottom:P.Metadata,rightTop:P.Masks,rightBottom:P.Curves},
  panelSwitcherPlacement:{leftTop:'right',leftBottom:'top',rightTop:'left',rightBottom:'top'},
};
const fixed = tether => ({leftTop:[P.Curves,P.Metadata,P.FolderTree,P.Export,...(tether?[P.Tethering]:[])],leftBottom:[P.Crop,P.Masks,P.Ai,P.Presets],rightTop:[P.Adjustments],rightBottom:[]});
for(const platform of ['linux','windows','macos','']) for(const tether of [false,true]) test(`fixed saved layout ${platform||'unknown'} tether=${tether}`,()=>{
  const source=structuredClone(nasty), result=current.reconcileWorkspace(source,tether,platform,true);
  assert.deepEqual(result.panelLayout,fixed(tether));
  assert.deepEqual(result.activePanels,{leftTop:P.Curves,leftBottom:P.Presets,rightTop:P.Adjustments,rightBottom:null});
  assert.deepEqual(result.panelSwitcherPlacement,{leftTop:'bottom',leftBottom:'bottom',rightTop:'right',rightBottom:'right'});
  for(const key of ['leftPanelWidth','rightPanelWidth','leftTopHeight','rightTopHeight'])assert.equal(result[key],nasty[key]);
  assert.deepEqual(source,nasty);
});
test('full layout retains dimensions even with absent saved layout and zero width',()=>{
  const result=current.reconcileWorkspace({leftPanelWidth:0,rightPanelWidth:500,leftTopHeight:222,rightTopHeight:333},false,'linux',true);
  assert.equal(result.leftPanelWidth,0);assert.equal(result.rightPanelWidth,500);assert.equal(result.leftTopHeight,222);assert.equal(result.rightTopHeight,333);
  assert.deepEqual(result.panelLayout,fixed(false));
});
test('desktop init defaults via reconciliation',()=>{reset();const s=current.useUIStore.getState();assert.deepEqual(s.panelLayout,fixed(true));assert.equal(s.activePanels.leftBottom,P.Presets);assert.equal(s.leftPanelWidth,250);assert.equal(s.rightPanelWidth,320);assert.equal(s.leftTopHeight,340);});
for(const tool of tools) test(`full initialization workspace clears stale ${tool} with no image`,()=>{
  reset(current,'linux',true,false);current.useUIStore.setState({activePanel:tool,renderedPanel:tool,activePanels:{leftTop:P.FolderTree,leftBottom:tool,rightTop:tool,rightBottom:P.Presets}});
  current.useUIStore.getState().setUI(current.reconcileWorkspace(nasty,true,'linux',true));
  const n=current.useUIStore.getState();assert.equal(n.activePanel,P.Adjustments);assert.equal(n.renderedPanel,P.Adjustments);assert.equal(n.activePanels.leftBottom,P.Presets);assert.deepEqual(n.panelLayout,fixed(true));
});
for (const platform of ['android','linux']) for(const full of [false,true]) {
  if(platform==='linux' && full)continue;
  for(const saved of [undefined,nasty,{...nasty,panelLayout:{}},{...nasty,panelLayout:{leftTop:[P.FolderTree],leftBottom:[],rightTop:[],rightBottom:[]}}]) for(const tether of [false,true]) test(`baseline reconcile ${platform} full=${full} saved=${saved?.panelLayout ? JSON.stringify(saved.panelLayout) : 'none'} tether=${tether}`,()=>assert.deepEqual(current.reconcileWorkspace(saved,tether,platform,full),old.reconcileWorkspace(saved,tether,platform,full)));
}
for(const tool of tools) for(const method of ['shortcut','regional']) test(`enter ${tool} via ${method}`,()=>{
  reset();const s=current.useUIStore.getState();method==='shortcut'?s.setPanel(tool):s.setActivePanel('leftBottom',tool);
  const n=current.useUIStore.getState();assert.equal(n.activePanel,tool);assert.equal(n.renderedPanel,tool);assert.equal(n.activePanels.leftBottom,tool);assert.equal(n.activePanels.rightTop,P.Adjustments);
});
for(const tool of tools) for(const [region,panel] of [['rightTop',P.Adjustments],['leftTop',P.Curves],['leftTop',P.FolderTree],['leftTop',P.Tethering]]) test(`${tool} survives content ${panel}`,()=>{
  reset();current.useUIStore.getState().setPanel(tool);const snapshot=current.useEditorStore.getState().cropSessionSnapshot;
  current.useUIStore.getState().setActivePanel(region,panel);const n=current.useUIStore.getState();
  assert.equal(n.activePanel,tool);assert.equal(n.renderedPanel,tool);assert.equal(n.activePanels.leftBottom,tool);assert.equal(current.useEditorStore.getState().cropSessionSnapshot,snapshot);
});
for(const tool of tools) for(const method of ['preset shortcut','preset regional','explicit adjustments']) test(`exit ${tool} via ${method}`,()=>{
  reset();current.useUIStore.getState().setPanel(tool);const s=current.useUIStore.getState();
  if(method==='preset shortcut')s.setPanel(P.Presets);else if(method==='preset regional')s.setActivePanel('leftBottom',P.Presets);else s.setPanel(P.Adjustments);
  const n=current.useUIStore.getState();assert.equal(n.activePanel,P.Adjustments);assert.equal(n.renderedPanel,P.Adjustments);assert.equal(n.activePanels.leftBottom,P.Presets);assert.equal(current.useEditorStore.getState().cropSessionSnapshot,null);
});
for(const tool of tools) for(const next of tools) test(`switch ${tool} -> ${next}`,()=>{reset();current.useUIStore.getState().setPanel(tool);current.useUIStore.getState().setPanel(next);assert.equal(current.useUIStore.getState().activePanel,next);assert.equal(current.useUIStore.getState().activePanels.leftBottom,next);});
for(const panel of [...tools,P.Presets]) for(const hidden of [false,true]) for(const width of [0,199,200,400]) test(`reopen left ${panel} hidden=${hidden} width=${width}`,()=>{
  reset();const s=current.useUIStore.getState();s.setUI({leftPanelWidth:width,rightPanelWidth:123,uiVisibility:{...s.uiVisibility,leftPanel:!hidden,rightPanel:false}});s.setPanel(panel);
  const n=current.useUIStore.getState();assert.equal(n.uiVisibility.leftPanel,true);assert.equal(n.leftPanelWidth,(hidden||width<200)&&width<250?250:width);assert.equal(n.uiVisibility.rightPanel,false);assert.equal(n.rightPanelWidth,123);
});
for(const tool of tools) for(const method of ['shortcut','regional']) test(`no-image rejects ${tool} via ${method}`,()=>{
  reset(current,'linux',true,false);const before=snapshot(current),s=current.useUIStore.getState();method==='shortcut'?s.setPanel(tool):s.setActivePanel('leftBottom',tool);assert.deepEqual(snapshot(current),before);
});
for(const tool of tools) test(`selection loss resets ${tool} without reopening hidden sidebar`,()=>{
  reset();const s=current.useUIStore.getState();s.setPanel(tool);s.setUI({uiVisibility:{...s.uiVisibility,leftPanel:false},leftPanelWidth:101});current.useEditorStore.getState().setEditor({selectedImage:null});
  const n=current.useUIStore.getState();assert.equal(n.activePanel,P.Adjustments);assert.equal(n.renderedPanel,P.Adjustments);assert.equal(n.activePanels.leftBottom,P.Presets);assert.equal(n.uiVisibility.leftPanel,false);assert.equal(n.leftPanelWidth,101);assert.equal(current.useEditorStore.getState().cropSessionSnapshot,null);
});
for(const platform of ['android','linux']) for(const full of [false,true]) {
  if(platform==='linux'&&full)continue;
  test(`selection loss guard ${platform} full=${full}`,()=>{reset(current,platform,full);current.useUIStore.getState().setPanel(P.Masks);const before=snapshot(current);current.useEditorStore.getState().setEditor({selectedImage:null});assert.deepEqual(snapshot(current),before);});
}
for(const panel of allPanels) test(`compact -> full ${panel}`,()=>{
  reset(current,'linux',false,true,nasty);current.useUIStore.getState().setPanel(panel);
  const before=current.useUIStore.getState(),expected=tools.includes(before.activePanel)?before.activePanel:P.Adjustments;
  before.setUI({isFullLayout:true});const n=current.useUIStore.getState();
  assert.deepEqual(n.panelLayout,fixed(true));assert.equal(n.activePanel,expected);assert.equal(n.renderedPanel,expected);assert.equal(n.activePanels.leftBottom,tools.includes(expected)?expected:P.Presets);assert.equal(n.activePanels.rightTop,P.Adjustments);assert.equal(n.activePanels.rightBottom,null);assert.equal(n.activeLayoutDragItem,null);assert.equal(n.leftPanelWidth,173);assert.deepEqual(n.panelSwitcherPlacement,{leftTop:'bottom',leftBottom:'bottom',rightTop:'right',rightBottom:'right'});
});
for(const tool of tools) test(`full -> compact -> Presets -> full from ${tool}`,()=>{
  reset();current.useUIStore.getState().setPanel(tool);current.useUIStore.getState().setUI({isFullLayout:false});assert.equal(current.useUIStore.getState().activePanel,tool);
  current.useUIStore.getState().setPanel(P.Presets);assert.equal(current.useUIStore.getState().activePanel,P.Presets);assert.equal(current.useUIStore.getState().renderedPanel,P.Presets);
  current.useUIStore.getState().setUI({isFullLayout:true});assert.equal(current.useUIStore.getState().activePanel,P.Adjustments);assert.equal(current.useUIStore.getState().activePanels.leftBottom,P.Presets);
});
test('compact selection overrides stale regional tool when returning to full',()=>{reset();const s=current.useUIStore.getState();s.setPanel(P.Crop);s.setUI({isFullLayout:false});s.setPanel(P.Adjustments);s.setUI({isFullLayout:true});assert.equal(current.useUIStore.getState().activePanel,P.Adjustments);assert.equal(current.useUIStore.getState().activePanels.leftBottom,P.Presets);});
test('full -> compact uses global Adjustments despite default regional Presets',()=>{reset();current.useUIStore.getState().setUI({isFullLayout:false});assert.equal(current.useUIStore.getState().activePanel,P.Adjustments);assert.equal(current.useUIStore.getState().renderedPanel,P.Adjustments);});
test('enter full without image clears compact tool',()=>{reset(current,'linux',false);const s=current.useUIStore.getState();s.setPanel(P.Crop);current.useEditorStore.getState().setEditor({selectedImage:null});s.setUI({isFullLayout:true});assert.equal(current.useUIStore.getState().activePanel,P.Adjustments);assert.equal(current.useUIStore.getState().activePanels.leftBottom,P.Presets);});
test('functional setUI and combined transition workspace honor fixed regions and dimensions',()=>{reset(current,'linux',false);current.useUIStore.getState().setPanel(P.Ai);current.useUIStore.getState().setUI(()=>({...nasty,isFullLayout:true,activeLayoutDragItem:P.Crop}));const n=current.useUIStore.getState();assert.deepEqual(n.panelLayout,fixed(true));assert.equal(n.activePanel,P.Ai);assert.equal(n.activePanels.leftBottom,P.Ai);assert.equal(n.rightPanelWidth,487);assert.equal(n.activeLayoutDragItem,null);});
for(const panel of [P.Metadata,P.Export]) for(const tool of tools) test(`modal ${panel} preserves ${tool}`,()=>{reset();current.useUIStore.getState().setPanel(tool);const before=snapshot(current);current.useUIStore.getState().setPanel(panel);assert.deepEqual(snapshot(current),{...before,panelModal:panel});current.useUIStore.getState().setUI({isFullLayout:false});assert.equal(current.useUIStore.getState().panelModal,null);assert.equal(current.useUIStore.getState().activePanel,tool);});
for(const panel of [P.Metadata,P.Export]) test(`modal ${panel} image/editor guard and library allowance`,()=>{reset(current,'linux',true,false);current.useUIStore.getState().setPanel(panel);assert.equal(current.useUIStore.getState().panelModal,null);current.useUIStore.getState().setUI({activeView:'library'});current.useUIStore.getState().setPanel(panel);assert.equal(current.useUIStore.getState().panelModal,panel);});
for(const panel of allPanels) for(const region of regions) test(`full mutation guards ${panel} ${region}`,()=>{reset();const s=current.useUIStore.getState(),before=snapshot(current);s.movePanel(panel,region);assert.deepEqual(snapshot(current),before);s.movePanelToIndex(panel,region,0);assert.deepEqual(snapshot(current),before);s.setPanelSwitcherPlacement(region,'top');assert.deepEqual(snapshot(current),before);s.setLayoutDragItem(panel);assert.deepEqual(snapshot(current),before);});
test('wrong regional requests cannot desynchronize tools',()=>{reset();current.useUIStore.getState().setPanel(P.Crop);const before=snapshot(current);current.useUIStore.getState().setActivePanel('rightTop',P.Masks);current.useUIStore.getState().setActivePanel('leftBottom',P.Adjustments);assert.deepEqual(snapshot(current),before);});
test('crop snapshot captures once, survives content, clears on exit and re-captures on entry',()=>{reset();const e=current.useEditorStore.getState();e.setEditor({adjustments:{...e.adjustments,rotation:12,exposure:2}});current.useUIStore.getState().setPanel(P.Crop);const crop=current.useEditorStore.getState().cropSessionSnapshot;assert.equal(crop.path,'/isolated/image.jpg');assert.deepEqual(crop.geometry,current.pickCropGeometry(current.useEditorStore.getState().adjustments));current.useUIStore.getState().setPanel(P.Crop);assert.equal(current.useEditorStore.getState().cropSessionSnapshot,crop);current.useUIStore.getState().setPanel(P.Adjustments);assert.equal(current.useEditorStore.getState().cropSessionSnapshot,null);e.setEditor({adjustments:{...e.adjustments,rotation:20}});current.useUIStore.getState().setPanel(P.Crop);assert.notEqual(current.useEditorStore.getState().cropSessionSnapshot,crop);});
test('reset workspace returns fixed defaults and clears tool',()=>{reset();current.useUIStore.getState().setPanel(P.Crop);const result=current.useUIStore.getState().resetWorkspaceLayout(true);assert.deepEqual(result.panelLayout,fixed(true));assert.equal(current.useUIStore.getState().activePanel,P.Adjustments);assert.equal(current.useUIStore.getState().activePanels.leftBottom,P.Presets);assert.equal(current.useEditorStore.getState().cropSessionSnapshot,null);});
for(const platform of ['android','linux']) for(const full of [false,true]) {
 if(platform==='linux'&&full)continue;
 test(`baseline action sequence ${platform} full=${full}`,()=>{
  reset(current,platform,full,true,nasty);reset(old,platform,full,true,nasty);
  const actions=[s=>s.setPanel(P.Crop),s=>s.setPanel(P.Presets),s=>s.setPanel(P.Adjustments),s=>s.setPanel(P.Metadata),s=>s.setPanel(P.Export),s=>s.setPanel(P.Masks),s=>s.setActivePanel('rightTop',P.Adjustments),s=>s.setLayoutDragItem(P.Ai),s=>s.movePanel(P.Ai,'leftBottom'),s=>s.movePanelToIndex(P.Presets,'rightBottom',0),s=>s.setPanelSwitcherPlacement('rightTop','top'),s=>s.setUI({isFullLayout:!full}),s=>s.setUI({isFullLayout:full}),s=>s.resetWorkspaceLayout(false)];
  // Android transitions are baseline-compatible. Desktop compact -> full is intentionally changed, so stop before transition.
  for(const action of platform==='linux'?actions.slice(0,11):actions){action(current.useUIStore.getState());action(old.useUIStore.getState());assert.deepEqual(snapshot(current),snapshot(old));}
 });
}
const regressionStart = results.length;
assert.equal(regressionStart,188,'Original suite remains 188 cases');
const ts = require('typescript');
const masksSource = readFileSync(`${root}/src/components/panel/right/MasksPanel.tsx`,'utf8');
const masksAst = ts.createSourceFile('MasksPanel.tsx',masksSource,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
let visibilityExpression;
let waveformDisabledUsesSelector = false;
function visitMasks(node) {
  if(ts.isPropertyAssignment(node) && node.name.getText(masksAst)==='isAdjustmentsPanelVisible') visibilityExpression=node.initializer.getText(masksAst);
  if(ts.isJsxAttribute(node) && node.name.getText(masksAst)==='disabled' && node.initializer?.getText(masksAst)==='{isAdjustmentsPanelVisible}') waveformDisabledUsesSelector=true;
  ts.forEachChild(node,visitMasks);
}
visitMasks(masksAst);
assert.ok(visibilityExpression,'Extract actual MasksPanel waveform visibility selector');
assert.ok(waveformDisabledUsesSelector,'Actual waveform button disabled prop consumes visibility selector');
const masksSelector=new Function('state','isPanelVisible','Panel',`return (${visibilityExpression});`);
const waveformDisabled=(m,s)=>masksSelector(s,m.isPanelVisible,m.Panel);
for(const platform of ['linux','windows','macos']) for(const tool of tools) test(`compact visibility ${platform} ${tool} ignores persistent right Adjustments`,()=>{
  reset(current,platform,true);const s=current.useUIStore.getState();s.setPanel(tool);s.setUI({isFullLayout:false});const n=current.useUIStore.getState();
  assert.equal(n.activePanels.rightTop,P.Adjustments,'full regional Adjustments persists on resize');
  assert.equal(n.activePanel,tool);assert.equal(current.isPanelVisible(n,tool),true);assert.equal(current.isPanelVisible(n,P.Adjustments),false);assert.equal(waveformDisabled(current,n),false);
});
for(const platform of ['linux','windows','macos']) test(`compact Masks waveform selector after opening tool in compact ${platform}`,()=>{
  reset(current,platform,true);current.useUIStore.getState().setUI({isFullLayout:false});current.useUIStore.getState().setPanel(P.Masks);const n=current.useUIStore.getState();
  assert.equal(n.activePanels.rightTop,P.Adjustments);assert.equal(n.activePanel,P.Masks);assert.equal(waveformDisabled(current,n),false);
});
for(const globalPanel of allPanels) test(`compact visibility global-only ${globalPanel} with both sidebars hidden`,()=>{
  reset(current,'linux',false);const s=current.useUIStore.getState();s.setUI({activePanel:globalPanel,uiVisibility:{...s.uiVisibility,leftPanel:false,rightPanel:false},activePanels:{leftTop:P.Curves,leftBottom:P.Crop,rightTop:P.Adjustments,rightBottom:P.Export}});const n=current.useUIStore.getState();
  for(const candidate of allPanels)assert.equal(current.isPanelVisible(n,candidate),candidate===globalPanel);
  assert.equal(waveformDisabled(current,n),globalPanel===P.Adjustments);
});
for(const platform of ['android','linux']) for(const full of [false,true]) for(const left of [false,true]) for(const right of [false,true]) {
  if(platform==='linux'&&!full)continue;
  test(`regional visibility baseline preserved ${platform} full=${full} left=${left} right=${right}`,()=>{
    reset(current,platform,full);reset(old,platform,full);
    const n={...current.useUIStore.getState(),isFullLayout:full,activePanel:P.Masks,activePanels:{leftTop:P.Curves,leftBottom:P.Presets,rightTop:P.Adjustments,rightBottom:P.Export},uiVisibility:{filmstrip:true,leftPanel:left,rightPanel:right,quickFilter:false}};
    for(const candidate of allPanels)assert.equal(current.isPanelVisible(n,candidate),old.isPanelVisible(n,candidate));
    assert.equal(waveformDisabled(current,n),right);
  });
}
for(const start of ['full Masks then compact','compact then Masks']) test(`true-base negative control: waveform disabled regression ${start}`,()=>{
  reset(current,'linux',true);reset(old,'linux',false);
  const s=current.useUIStore.getState();if(start==='full Masks then compact'){s.setPanel(P.Masks);s.setUI({isFullLayout:false});}else{s.setUI({isFullLayout:false});s.setPanel(P.Masks);}
  const n=current.useUIStore.getState();assert.equal(n.activePanels.rightTop,P.Adjustments);
  assert.equal(waveformDisabled(current,n),false,'patched selector enables Masks waveform');
  assert.equal(waveformDisabled(old,n),true,'exact 33ba1eb7 store selector reproduces disabled waveform against identical full-to-compact state');
});
test('full Masks waveform remains disabled until Adjustments sidebar hidden and enabled again in compact',()=>{
  reset();const s=current.useUIStore.getState();s.setPanel(P.Masks);assert.equal(waveformDisabled(current,current.useUIStore.getState()),true);
  s.setUI({uiVisibility:{...s.uiVisibility,rightPanel:false}});assert.equal(waveformDisabled(current,current.useUIStore.getState()),false);
  s.setUI({uiVisibility:{...s.uiVisibility,rightPanel:true}});assert.equal(waveformDisabled(current,current.useUIStore.getState()),true);
  s.setUI({isFullLayout:false});assert.equal(waveformDisabled(current,current.useUIStore.getState()),false);
  s.setPanel(P.Adjustments);assert.equal(waveformDisabled(current,current.useUIStore.getState()),true);
  s.setPanel(P.Masks);assert.equal(waveformDisabled(current,current.useUIStore.getState()),false);
});
const report={originalCases:regressionStart,compactVisibilityCases:results.length-regressionStart,negativeControls:{base:'33ba1eb7',expectedFailuresReproduced:results.filter(r=>r.name.startsWith('true-base negative control:')&&r.pass).length},sourceSha256:createHash('sha256').update(readFileSync(`${root}/src/store/useUIStore.ts`)).digest('hex'),base:'33ba1eb7f886a54d51a2922b6848654596da447d',total:results.length,passed:results.filter(r=>r.pass).length,failed:results.filter(r=>!r.pass).length,results};
writeFileSync('/tmp/task4-store-test-results.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({sourceSha256:report.sourceSha256,total:report.total,passed:report.passed,failed:report.failed}));
if(report.failed)process.exitCode=1;
