# Task 5 core isolated behavior harness — reproduction and archive notes

This file documents the commands actually used during the core implementation and the loading-snapshot fix. Adding this README did not rerun the tests or modify production sources.

## Environment and scope

- Repository: `/root/dev/work/tbt/RapidRAW`
- Harness directory: `/tmp/rapidraw-task5-core`
- Original Git base: `fbb76a9f53a75d05d181bd66826b5a5a43464239`
- Runtime: Node.js on Linux. The recorded negative-control stack reports Node.js `v26.13.0`.
- Bundler: the repository-installed `node_modules/.bin/esbuild` (package declaration `^0.28.2`; use the repository lockfile for the installed dependency set).
- Both TypeScript entrypoints import the real production stores, actions, adjustment utilities, and Panel enum using absolute paths under the repository above.
- The harness uses real Zustand stores and the real `lodash.debounce` implementation. It calls production store/actions APIs and checks results with `node:assert/strict`.
- **No host stubs, esbuild plugins, aliases, defines, injected globals, or dependency substitutions were used.** Tauri-related modules are bundled as normal dependencies, but the exercised scenarios do not invoke native host commands. This is an isolated state/action test, not native backend or browser/UI evidence.
- The harness sets up platform/workspace/image/adjustment state directly. It does not mount React, execute the navigation hook, run AI generation, decode images, or call native Tauri APIs. Cached/cold/returned-image scenarios execute the observed production store-update order explicitly.
- A real 550 ms timer is used for the post-cancel debounce check. Other scenarios explicitly flush/cancel the real debounce where the script says so.

## Entrypoints and expected results

1. `behavior.ts`: original 27 grouped behavior controls.
2. `behavior-loading.ts`: a copy of those controls plus three AI loading-snapshot regression groups: entry, resetHistory, and A -> B -> A while generation remains active. Expected final result: 30 grouped controls.

Each successful invocation prints one JSON document to stdout with `passed` and `results`. An assertion failure prints to stderr and sets a nonzero exit status. The scripts themselves are the authoritative assertions; group counts are not counts of individual assertions.

The absolute import paths in these entrypoints must resolve to the intended frozen production source tree. To reproduce elsewhere, explicitly relocate those imports or recreate that repository path, and record that adaptation. Do not silently point them at a different revision.

## Actual original-controls build and run commands

Run from the repository root:

```sh
cd /root/dev/work/tbt/RapidRAW
node_modules/.bin/esbuild /tmp/rapidraw-task5-core/behavior.ts --bundle --platform=node --format=cjs --outfile=/tmp/rapidraw-task5-core/behavior.cjs
node /tmp/rapidraw-task5-core/behavior.cjs > /tmp/rapidraw-task5-core/behavior-result.json
```

Explicit esbuild options were exactly:

- Entry: `/tmp/rapidraw-task5-core/behavior.ts`
- `bundle: true`
- `platform: 'node'`
- `format: 'cjs'`
- Outfile: `/tmp/rapidraw-task5-core/behavior.cjs`
- All other options: esbuild defaults. No host stubs or custom resolution options.

These commands were rerun after the loading-snapshot fix and produced the final 27-group result currently in `behavior-result.json`.

## Actual loading-regression build and run commands after the fix

```sh
cd /root/dev/work/tbt/RapidRAW
node_modules/.bin/esbuild /tmp/rapidraw-task5-core/behavior-loading.ts --bundle --platform=node --format=cjs --outfile=/tmp/rapidraw-task5-core/behavior-loading-after.cjs
node /tmp/rapidraw-task5-core/behavior-loading-after.cjs > /tmp/rapidraw-task5-core/behavior-loading-result.json
```

The same esbuild options apply, with the entry/outfile changed as shown. This produced the final 30-group result in `behavior-loading-result.json`.

The corrected store snapshot helper deep-clones AI patches and normalizes only snapshot `isLoading` to false. The three added groups assert that current generation loading and the active task remain intact, nested data remains independently copied, and Cancel/undo/redo after completion do not revive orphan loading.

## Expected negative control: loading snapshot before the fix

**This failure is an intentional, expected negative control, not a failed final test run.** It establishes that the added regression detects the pre-fix loading-snapshot behavior.

Before editing the helper, the exact commands were:

```sh
cd /root/dev/work/tbt/RapidRAW
node_modules/.bin/esbuild /tmp/rapidraw-task5-core/behavior-loading.ts --bundle --platform=node --format=cjs --outfile=/tmp/rapidraw-task5-core/behavior-loading-before.cjs
node /tmp/rapidraw-task5-core/behavior-loading-before.cjs > /tmp/rapidraw-task5-core/loading-before.stdout 2> /tmp/rapidraw-task5-core/loading-before.stderr
```

Observed exit status: `1`. The assertion was:

```text
AssertionError [ERR_ASSERTION]: entry: snapshot must not retain transient loading

true !== false
```

The run stops on the first added entry assertion. It does not claim that all three added groups ran against the old source. `loading-before.stdout` is empty because the script emits its JSON only after all groups complete.

Frozen pre-fix core hashes:

```text
af3022a3227001d06e14d097fae3b9a865fa300bd2e4e12e2b31da10d79b8f3e  src/store/useEditorStore.ts
251e18d772ff5e1c5d35edd0649e683a2a5cb67b5ed204929d8e10242b0a5ce6  src/store/useUIStore.ts
b8ef012d8ee7bddf88f61408a3e8d2e33eef38cddc877055439fe34942c84ca5  src/hooks/useEditorActions.ts
```

The retained `behavior-loading-before.cjs` contains the bundled pre-fix code and can be inspected independently. Rebuilding it against the current fixed source would replace the negative-control input and must not be presented as the original negative control.

## Final frozen core hashes

`freeze-loading.sha256` records:

```text
a4e2e127c6d5f5093505977392887803433785629bb862206df7401c4f443650  src/store/useEditorStore.ts
251e18d772ff5e1c5d35edd0649e683a2a5cb67b5ed204929d8e10242b0a5ce6  src/store/useUIStore.ts
b8ef012d8ee7bddf88f61408a3e8d2e33eef38cddc877055439fe34942c84ca5  src/hooks/useEditorActions.ts
```

## Suggested archive allowlist

Archive only the intentional evidence and reproducible harness inputs below, alongside the parent's full frozen source/dependency provenance:

- `README.md` (this file)
- `behavior.ts`
- `behavior-loading.ts`
- `behavior-result.json` (final original 27 controls)
- `behavior-loading-result.json` (final expanded 30 controls)
- `freeze-loading.sha256` (final core hashes)
- `report-loading.json` (supplemental report, including the expected negative-control stderr)
- `loading-before.stderr` (explicitly label as EXPECTED NEGATIVE CONTROL)
- `behavior-loading-before.cjs` (pre-fix negative-control bundled input, if retaining executable input evidence)
- Optionally `behavior.cjs` and `behavior-loading-after.cjs` (final bundled inputs)

Do not recursively archive the entire temporary directory. Exclude other exploratory/failed attempts, including any earlier harness setup failure. `loading-before.stdout` is empty and need not be archived. Older `report.json` / `freeze.sha256` describe the earlier pre-fix delivery; the final source provenance is `freeze-loading.sha256`.

Verification limits remain unchanged: Linux Node.js isolated state/action behavior only; no real native AI, browser, Windows/macOS, or Android hardware validation is claimed by these harness results.
