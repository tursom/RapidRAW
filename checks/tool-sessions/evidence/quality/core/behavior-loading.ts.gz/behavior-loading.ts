import assert from 'node:assert/strict';
import { useEditorStore as E } from '/root/dev/work/tbt/RapidRAW/src/store/useEditorStore';
import { useUIStore as U } from '/root/dev/work/tbt/RapidRAW/src/store/useUIStore';
import { useSettingsStore as S } from '/root/dev/work/tbt/RapidRAW/src/store/useSettingsStore';
import { useProcessStore as P } from '/root/dev/work/tbt/RapidRAW/src/store/useProcessStore';
import { INITIAL_ADJUSTMENTS, pickCropGeometry } from '/root/dev/work/tbt/RapidRAW/src/utils/adjustments';
import { Panel } from '/root/dev/work/tbt/RapidRAW/src/components/ui/AppProperties';
import { applyToolSession, cancelToolSession, applyCrop, cancelCrop, isToolSessionBusy, toolSessionBusy, debouncedSetHistory } from '/root/dev/work/tbt/RapidRAW/src/hooks/useEditorActions';
async function run() {
const results: string[] = [];
const image = (path: string, isReady = true) => ({path, isReady, width: 100, height: 100} as any);
const base = () => structuredClone(INITIAL_ADJUSTMENTS);
function start(tool: Panel, adj = base(), platform = 'linux') {
  debouncedSetHistory.cancel();
  S.setState({ osPlatform: platform });
  U.getState().resetWorkspaceLayout();
  U.getState().setUI({ activePanel: Panel.Adjustments });
  E.getState().setEditor({selectedImage: image('A'), isGeneratingAi: false, isGeneratingAiMask: false});
  E.getState().resetHistory(adj);
  P.getState().setProcess({activeAiTasks: {}});
  U.getState().setPanel(tool);
}
const edit = (patch: any) => {
  const adj = {...E.getState().adjustments, ...patch};
  E.getState().setEditor({adjustments: adj});
  debouncedSetHistory(adj);
  return adj;
};
const get = () => E.getState();
for (const tool of [Panel.Crop, Panel.Masks, Panel.Ai]) {
  start(tool);
  const initial = structuredClone(get().adjustments);
  const own = tool === Panel.Crop ? {rotation: 7, crop: {x: 5, y: 5, width: 80, height: 80}} : tool === Panel.Masks ? {masks: [{id:'m', subMasks:[{id:'sm', parameters:{points:[1,2]}}], adjustments:{exposure:3}}]} : {aiPatches:[{id:'a', isLoading:false, subMasks:[{id:'sm',parameters:{points:[1,2]}}], patchData:{pixels:[1,2]}}]};
  const beforeCancel = edit({...own, exposure: 2, curves: {...initial.curves, luma:[{x:0,y:12},{x:255,y:255}]}});
  // Repeated entry/content interactions must not replace the entry snapshot.
  U.getState().setPanel(tool);
  U.getState().setActivePanel('rightTop', Panel.Adjustments);
  cancelToolSession();
  assert.equal(U.getState().activePanel, Panel.Adjustments);
  assert.equal(get().adjustments.exposure, 2);
  assert.deepEqual(get().adjustments.curves, beforeCancel.curves);
  if (tool === Panel.Crop) assert.deepEqual(pickCropGeometry(get().adjustments), pickCropGeometry(initial));
  if (tool === Panel.Masks) assert.deepEqual(get().adjustments.masks, initial.masks);
  if (tool === Panel.Ai) assert.deepEqual(get().adjustments.aiPatches, initial.aiPatches);
  assert.equal(get().history.length,3);
  debouncedSetHistory.flush();
  assert.equal(get().history.length,3);
  get().undo();
  assert.deepEqual(get().adjustments,beforeCancel);
  get().redo();
  assert.equal(get().adjustments.exposure,2);
  results.push(`${tool}: pending history cancel / own fields / sliders curves / reentry / undo redo`);
  start(tool);
  cancelToolSession();
  assert.equal(get().history.length,1);
  results.push(`${tool}: unchanged cancel adds no history`);
  start(tool);
  const applied = edit(own);
  applyToolSession();
  assert.deepEqual(get().adjustments, applied);
  assert.equal(U.getState().activePanel,Panel.Adjustments);
  assert.equal(get().history.length,2);
  results.push(`${tool}: apply preserves direct pending content`);
  for (const cached of [false,true]) {
    start(tool);
    edit(own);
    get().setEditor({selectedImage:image('B',cached)});
    assert.equal(get().cropSessionSnapshot,null);
    assert.equal(get().masksSessionSnapshot,null);
    assert.equal(get().aiSessionSnapshot,null);
    const loadingState = get().adjustments;
    cancelToolSession(); applyToolSession();
    assert.equal(U.getState().activePanel,tool);
    assert.equal(get().adjustments,loadingState);
    const loaded = {...base(), exposure:4, rotation:2};
    get().setEditor({adjustments:loaded});
    cancelToolSession();
    assert.equal(get().adjustments,loaded);
    get().resetHistory(loaded);
    if (!cached) {
      cancelToolSession();
      assert.equal(U.getState().activePanel,tool);
      get().setEditor({selectedImage:image('B')});
    }
    edit({...own,exposure:5});
    cancelToolSession();
    assert.equal(get().adjustments.rotation,loaded.rotation);
    assert.equal(get().adjustments.exposure,5);
    assert.equal(get().selectedImage?.path,'B');
    get().undo();
    assert.equal(get().adjustments.exposure,5);
    results.push(`${tool}: ${cached?'cached':'cold'} path-first / adjustments-before-reset / reset-before-ready / new snapshot`);
  }
}
for (const busy of [
  {isGeneratingAi:true}, {isGeneratingAiMask:true},
  {adjustments:{...base(),aiPatches:[{id:'patch',isLoading:true,subMasks:[]}]}},
  {adjustments:{...base(),masks:[{id:'mask',isLoading:true,subMasks:[]}]}}
]) {
  start(Panel.Masks);
  get().setEditor(busy as any);
  assert.equal(isToolSessionBusy(),true);
  assert.equal(toolSessionBusy(get(),P.getState()),true);
  const state=get();
  cancelToolSession(); applyToolSession(); cancelCrop(); applyCrop();
  assert.equal(get(),state);
  assert.equal(U.getState().activePanel,Panel.Masks);
}
start(Panel.Ai);
P.getState().registerAiTask('actual-submask-id','subject');
assert.equal(isToolSessionBusy(),true);
cancelToolSession(); applyToolSession();
assert.equal(U.getState().activePanel,Panel.Ai);
P.getState().unregisterAiTask('actual-submask-id');
assert.equal(isToolSessionBusy(),false);
results.push('busy: AI / AI mask / patch loading / mask loading / actual submask task / all four public actions');
start(Panel.Crop);
edit({rotation:8});
U.getState().setPanel(Panel.Masks);
assert.equal(get().adjustments.rotation,8);
edit({masks:[{id:'m',subMasks:[],adjustments:{}}]});
U.getState().setPanel(Panel.Ai);
edit({aiPatches:[{id:'a',isLoading:false,subMasks:[]}]});
cancelToolSession();
assert.equal(get().adjustments.rotation,8);
assert.equal(get().adjustments.masks.length,1);
assert.equal(get().adjustments.aiPatches.length,0);
results.push('tool switch applies prior geometry/masks and cancel restores only active AI');
start(Panel.Masks, {...base(), masks:[{id:'entry',subMasks:[{parameters:{points:[1]}}],adjustments:{}}]} as any);
get().adjustments.masks[0].subMasks[0].parameters.points[0]=99;
cancelToolSession();
assert.equal(get().adjustments.masks[0].subMasks[0].parameters.points[0],1);
get().undo();
assert.equal(get().adjustments.masks[0].subMasks[0].parameters.points[0],99);
results.push('deep nested mask entry snapshot and isolated cancel undo');
start(Panel.Ai, {...base(),aiPatches:[{id:'entry',isLoading:false,subMasks:[],patchData:{pixels:[1]}}]} as any);
get().adjustments.aiPatches[0].patchData.pixels[0]=99;
cancelToolSession();
assert.equal(get().adjustments.aiPatches[0].patchData.pixels[0],1);
results.push('deep nested AI patchData entry snapshot');
start(Panel.Crop);
edit({rotation:12});
applyCrop();
assert.equal(U.getState().activePanel,Panel.Adjustments);
U.getState().setPanel(Panel.Crop);
edit({rotation:21});
cancelCrop();
assert.equal(get().adjustments.rotation,12);
results.push('desktop legacy crop entrypoints delegate to current session');
start(Panel.Masks);
const settled = edit({masks:[{id:'settled', subMasks:[],adjustments:{}}],exposure:6});
debouncedSetHistory.flush();
assert.equal(get().history.length,2);
cancelToolSession();
assert.equal(get().history.length,3);
get().undo();
assert.deepEqual(get().adjustments,settled);
results.push('settled history cancel adds exactly one step');
start(Panel.Ai);
edit({aiPatches:[{id:'cached-old',isLoading:false,subMasks:[]}]});
const fresh = {...base(),aiPatches:[{id:'fresh-metadata',isLoading:false,subMasks:[]}]};
get().setEditor({adjustments:fresh});
get().resetHistory(fresh);
assert.equal(get().aiSessionSnapshot?.aiPatches[0].id,'fresh-metadata');
edit({aiPatches:[]});
cancelToolSession();
assert.equal(get().adjustments.aiPatches[0].id,'fresh-metadata');
results.push('cached background metadata reset rebuilds active tool snapshot and clears stale debounce');
start(Panel.Masks);
edit({exposure:6});
cancelToolSession();
debouncedSetHistory.flush();
assert.equal(get().history.length,2);
assert.equal(get().adjustments.exposure,6);
results.push('unchanged tool cancel keeps pending slider history without extra cancellation row');
for (const compact of [false,true]) {
 start(Panel.Masks);
 if (compact) U.getState().setUI({isFullLayout:false});
 edit({masks:[{id:'before-compact',subMasks:[],adjustments:{}}]});
 U.getState().setUI({isFullLayout:!compact});
 cancelToolSession();
 assert.equal(get().adjustments.masks.length,0);
 results.push(`layout transition ${compact?'compact to full':'full to compact'} preserves entry snapshot`);
}
U.getState().setUI({isFullLayout:true});
start(Panel.Masks);
edit({masks:[{id:'real-timer',subMasks:[],adjustments:{}}]});
cancelToolSession();
const restoredAfterCancel = structuredClone(get().adjustments);
// A later UI write of the restored state must not produce a duplicate history step.
debouncedSetHistory(get().adjustments);
await new Promise(resolve => setTimeout(resolve,550));
assert.deepEqual(get().adjustments,restoredAfterCancel);
assert.equal(get().history.length,3);
get().undo();
assert.equal(get().adjustments.masks[0].id,'real-timer');
results.push('real 550ms timer after cancel: no duplicate, no overwrite, undo recovers tool content');
for (const boundary of ['entry', 'reset', 'returned-A']) {
  const pendingPatch = {id:'loading-A',isLoading:true,subMasks:[{id:'sub-A',parameters:{points:[1,2]}}],patchData:{pixels:[3,4]},prompt:'entry prompt',visible:true};
  const pendingAdjustments = {...base(),aiPatches:[pendingPatch]};
  start(boundary === 'entry' ? Panel.Masks : Panel.Ai, pendingAdjustments as any);
  P.getState().registerAiTask('loading-A','inpaint');
  if (boundary === 'entry') U.getState().setPanel(Panel.Ai);
  if (boundary === 'reset') get().resetHistory(pendingAdjustments as any);
  if (boundary === 'returned-A') {
    const cachedA = structuredClone(get().adjustments);
    get().setEditor({selectedImage:image('B')});
    get().resetHistory(base());
    get().setEditor({selectedImage:image('A')});
    get().setEditor({adjustments:cachedA});
    get().resetHistory(cachedA);
  }
  const snapshot = get().aiSessionSnapshot!;
  assert.equal(snapshot.path,'A');
  assert.equal(snapshot.aiPatches[0].isLoading,false,`${boundary}: snapshot must not retain transient loading`);
  assert.equal(get().adjustments.aiPatches[0].isLoading,true,`${boundary}: actual generation must remain loading`);
  assert.deepEqual(snapshot.aiPatches[0],{...pendingPatch,isLoading:false});
  assert.notEqual(snapshot.aiPatches[0].patchData,get().adjustments.aiPatches[0].patchData);
  assert.notEqual(snapshot.aiPatches[0].subMasks[0].parameters,get().adjustments.aiPatches[0].subMasks[0].parameters);
  assert.equal(P.getState().isAiTaskRunning('loading-A'),true);
  cancelToolSession();
  assert.equal(U.getState().activePanel,Panel.Ai);
  assert.equal(get().adjustments.aiPatches[0].isLoading,true);
  assert.equal(P.getState().isAiTaskRunning('loading-A'),true);
  const completed = edit({aiPatches:[{...pendingPatch,isLoading:false,patchData:{pixels:[8,9]},prompt:'completed prompt'}]});
  P.getState().unregisterAiTask('loading-A');
  assert.equal(isToolSessionBusy(),false);
  cancelToolSession();
  assert.equal(U.getState().activePanel,Panel.Adjustments);
  assert.deepEqual(get().adjustments.aiPatches,[{...pendingPatch,isLoading:false}]);
  assert.equal(isToolSessionBusy(),false,`${boundary}: cancel must not create orphan loading`);
  get().undo();
  assert.deepEqual(get().adjustments,completed);
  assert.equal(isToolSessionBusy(),false,`${boundary}: undo must restore completed data without orphan loading`);
  get().redo();
  assert.equal(get().adjustments.aiPatches[0].isLoading,false);
  assert.equal(isToolSessionBusy(),false);
  results.push(`AI transient loading ${boundary}: deep copied data / live generation and task preserved / cancel undo redo no orphan loading`);
}
start(Panel.Crop,base(),'android');
edit({rotation:9});
cancelCrop();
assert.equal(get().adjustments.rotation,0);
assert.equal(get().history.length,1); // original asynchronous history behavior
assert.equal(U.getState().activePanel,Panel.Adjustments);
debouncedSetHistory.flush();
assert.equal(get().history.length,2);
results.push('Android original crop cancel asynchronous history and panel behavior');
debouncedSetHistory.cancel();
console.log(JSON.stringify({passed:results.length,results},null,2));
}
run().catch(error => { console.error(error); process.exitCode = 1; });
