import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
const out=dirname(fileURLToPath(import.meta.url));
const repo='/root/dev/work/tbt/RapidRAW';
const require=createRequire(resolve(repo,'package.json'));
const esbuild=require('esbuild');
const {compile}=require('@tailwindcss/node');
const {Scanner}=require('@tailwindcss/oxide');
const {chromium}=await import('/root/.npm/_npx/dd48173ecf795e2b/node_modules/playwright/index.mjs');
const sha=b=>createHash('sha256').update(b).digest('hex');
const sourcePath=resolve(repo,'src/components/panel/editor/ToolSessionActions.tsx');
const source=await readFile(sourcePath,'utf8');
assert.equal(sha(source),'c0bb3f49adbb2c8ecab376e59c22c3195d0161b218ed61b48f7afab357ec5eae');
const old=source.replace('className="bg-surface text-text-primary"','className="bg-surface"');
assert.notEqual(old,source);
assert.equal(sha(old),'2b1841cce06208ec8686ac858f12b67f7be26838c64cf301ae1e386b72e26ad4');
const freeze=JSON.parse(await readFile('/tmp/tbt-sessions-source-freeze.json','utf8'));
for(const f of freeze.files) if(!f.path.endsWith('/ToolSessionActions.tsx')) assert.equal(sha(await readFile(resolve(repo,f.path))),f.sha256,f.path);
const buttonPath=resolve(repo,'src/components/ui/Button.tsx');
const button=await readFile(buttonPath);
assert.equal(sha(button),sha(execFileSync('git',['show','fbb76a9f:src/components/ui/Button.tsx'],{cwd:repo})));
const cssPath=resolve(repo,'src/styles.css');const cssSource=await readFile(cssPath,'utf8');
const compiler=await compile(cssSource,{base:dirname(cssPath),from:cssPath,onDependency(){}});
const scanner=new Scanner({sources:[...(compiler.root && compiler.root!=='none'?[{...compiler.root,negated:false}]:[]),...compiler.sources]});const candidates=scanner.scan();
assert.ok(candidates.includes('text-button-text')&&candidates.includes('text-text-primary'));
const css=compiler.build(candidates);await writeFile(resolve(out,'generated.css'),css);
assert.ok(css.includes('.text-button-text')&&css.includes('.text-text-primary'));
const colorRulePositions={buttonText:css.indexOf('.text-button-text'),textPrimary:css.indexOf('.text-text-primary')};
const report={scope:'Local Chromium controlled CSS test using fresh actual project Tailwind compilation, unchanged production Button, actual ToolSessionActions and THEMES. Explicit store/actions/translation boundaries, no Windows or full editor/native visual claim.',sourceSha256:sha(source),oldSourceReconstructedSha256:sha(old),otherSevenSourcesUnchanged:true,sharedButtonUnchangedFromBase:true,sharedButtonSha256:sha(button),stylesSourceSha256:sha(cssSource),generatedCssSha256:sha(css),candidateCount:candidates.length,colorRulePositions,cases:[],errors:[]};
function luminance(rgb){return rgb.map(x=>x/255).map(x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4).reduce((n,x,i)=>n+x*[.2126,.7152,.0722][i],0)}
function contrast(a,b){const x=luminance(a),y=luminance(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)}
const rgb=s=>s.match(/[\d.]+/g).slice(0,3).map(Number);
let browser;
try{
 browser=await chromium.launch({executablePath:'/root/.cache/ms-playwright/chromium-1254/chrome-linux64/chrome',headless:true,args:['--no-sandbox']});report.browserVersion=browser.version();
 for(const variant of ['old-negative','current']){
  const plugin={name:'explicit-css-review-boundaries',setup(build){
   build.onResolve({filter:/useEditorStore$|useProcessStore$|useSettingsStore$|useUIStore$|useEditorActions$|^react-i18next$/},()=>({path:'boundary',namespace:'boundary'}));
   build.onLoad({filter:/.*/,namespace:'boundary'},()=>({contents:`const editor={selectedImage:{path:'CSS-only.NEF',isReady:true},isGeneratingAi:false,isGeneratingAiMask:false,adjustments:{masks:[],aiPatches:[]}};export const useEditorStore=s=>s(editor),useProcessStore=s=>s({activeAiTasks:{}}),useSettingsStore=s=>s({osPlatform:'windows'}),useUIStore=s=>s({activePanel:'crop'});export const toolSessionBusy=()=>false;export const applyToolSession=()=>window.handlers.push('apply'),cancelToolSession=()=>window.handlers.push('cancel');export function useTranslation(){return{t:key=>key.endsWith('apply')?'Apply':'Cancel'}}`,loader:'js',resolveDir:repo}));
   build.onLoad({filter:/ToolSessionActions\.tsx$/},()=>({contents:variant==='current'?source:old,loader:'tsx',resolveDir:dirname(sourcePath)}));
  }};
  const built=await esbuild.build({stdin:{contents:`import React from 'react';import{createRoot}from'react-dom/client';import{flushSync}from'react-dom';import ToolSessionActions from './src/components/panel/editor/ToolSessionActions';import{THEMES}from'./src/utils/themes';window.themes=THEMES;window.handlers=[];window.inputs=[];document.addEventListener('click',e=>window.inputs.push({trusted:e.isTrusted,action:e.target.closest('[data-tool-session-action]')?.dataset.toolSessionAction}),true);flushSync(()=>createRoot(document.getElementById('actions-host')).render(<ToolSessionActions/>));`,loader:'tsx',sourcefile:'review.tsx',resolveDir:repo},bundle:true,platform:'browser',format:'iife',write:false,jsx:'automatic',define:{'process.env.NODE_ENV':'"production"'},plugins:[plugin],logLevel:'silent'});
  const page=await browser.newPage({viewport:{width:1280,height:720},deviceScaleFactor:1});page.on('pageerror',e=>report.errors.push(String(e)));
  await page.setContent(`<style>${css}</style><style>body{margin:0;background:var(--app-bg-primary);font-family:Arial}#editor{position:absolute;left:308px;top:56px;width:644px;height:456px}#toolbar{height:48px;background:var(--app-surface)}#viewport{background:rgb(110,130,150)}#actions-host{display:contents}</style><main id="editor" class="flex flex-col relative overflow-hidden rounded-lg p-2 gap-2"><header id="toolbar" class="shrink-0 relative z-10"></header><div id="viewport" class="flex-1 flex relative overflow-hidden isolate rounded-lg ring-[9999px] ring-bg-secondary"></div><div id="actions-host"></div></main>`);
  await page.addScriptTag({content:built.outputFiles[0].text});
  for(let index=0;index<3;index++){
   const observed=await page.evaluate(async index=>{
    const theme=window.themes[index];for(const[k,v]of Object.entries(theme.cssVariables))document.documentElement.style.setProperty(k,v);
    await document.fonts.ready;await new Promise(done=>requestAnimationFrame(()=>requestAnimationFrame(done)));
    return {theme:theme.name,tokens:theme.cssVariables,bar:(()=>{const e=document.querySelector('[data-tool-session-actions]'),s=getComputedStyle(e);return{position:s.position,zIndex:s.zIndex,rect:e.getBoundingClientRect().toJSON()}})(),buttons:[...document.querySelectorAll('[data-tool-session-action]')].map(e=>{const s=getComputedStyle(e);return{action:e.dataset.toolSessionAction,className:e.className,color:s.color,backgroundColor:s.backgroundColor,disabled:e.disabled,rect:e.getBoundingClientRect().toJSON()}})};
   },index);
   const cancel=observed.buttons.find(b=>b.action==='cancel'),apply=observed.buttons.find(b=>b.action==='apply');
   assert.equal(cancel.color,observed.tokens[variant==='current'?'--app-text-primary':'--app-button-text']);
   assert.equal(cancel.backgroundColor,observed.tokens['--app-surface']);assert.equal(apply.color,observed.tokens['--app-button-text']);assert.equal(apply.backgroundColor,observed.tokens['--app-accent']);
   assert.equal(observed.bar.position,'relative');assert.equal(observed.bar.zIndex,'10');
   cancel.contrastRatio=contrast(rgb(cancel.color),rgb(cancel.backgroundColor));assert.equal(cancel.contrastRatio>=4.5,variant==='current');
   const name=`${variant}-${index}.png`;const png=await page.screenshot({path:resolve(out,name)});
   for(const action of ['apply','cancel'])await page.locator(`[data-tool-session-action="${action}"]`).click();
   const events=await page.evaluate(()=>({handlers:window.handlers.splice(0),inputs:window.inputs.splice(0)}));
   assert.deepEqual(events.handlers,['apply','cancel']);assert.ok(events.inputs.length===2&&events.inputs.every(e=>e.trusted));
   report.cases.push({variant,...observed,events,screenshot:{path:name,sha256:sha(png),bytes:png.length}});
  }
  await page.close();
 }
 for(let i=0;i<3;i++)assert.deepEqual(report.cases[i].buttons.map(b=>b.rect),report.cases[i+3].buttons.map(b=>b.rect));
 assert.equal(sha(await readFile(sourcePath)),report.sourceSha256);assert.equal(sha(await readFile(buttonPath)),report.sharedButtonSha256);assert.equal(sha(await readFile(cssPath)),report.stylesSourceSha256);assert.deepEqual(report.errors,[]);report.sourceUnchangedAfter=true;report.status='SOURCE_FREEZE_PASS';
}catch(e){report.status='FAILED';report.errors.push(e.stack??String(e));process.exitCode=1;}
finally{await browser?.close();esbuild.stop();report.cleanup={browserClosed:true,esbuildStopped:true};report.scriptSha256=sha(await readFile(fileURLToPath(import.meta.url)));await writeFile(resolve(out,'report.json'),JSON.stringify(report,null,2)+'\n');}
console.log(JSON.stringify({status:report.status,source:report.sourceSha256,oldSource:report.oldSourceReconstructedSha256,colorRulePositions:report.colorRulePositions,cases:report.cases.map(c=>({variant:c.variant,theme:c.theme,cancel:c.buttons.find(b=>b.action==='cancel')})),errors:report.errors},null,2));
