import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';

const directory = dirname(fileURLToPath(import.meta.url));
const repository = process.env.TASK5_REPOSITORY ?? '/root/dev/work/tbt/RapidRAW';
const sourcePath = resolve(repository, 'node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs');
const original = await readFile(sourcePath, 'utf8');
const source = original.replace(/^import .*;\n/gm, '').replace(/^export .*;\n/gm, '');
const sha = (value) => createHash('sha256').update(value).digest('hex');

// This is a controlled hook scheduler, not React's runtime scheduler. It executes
// the installed AnimatePresence function unchanged after replacing its imports.
// In particular, the early onExit callback is deliberately delivered before the
// parent layout effect. Native evidence does NOT record this callback ordering.
function runtime() {
  const slots = [];
  let index = 0;
  let dirty = false;
  let effects = [];
  const same = (a, b) => a && b && a.length === b.length && a.every((value, i) => Object.is(value, b[i]));
  const next = (initialize) => {
    const position = index++;
    if (!(position in slots)) slots[position] = initialize();
    return slots[position];
  };
  const context = {
    jsx: (type, props, key) => ({ type, props, key }),
    Fragment: 'fragment', PresenceChild: 'PresenceChild', LayoutGroupContext: {},
    usePresence: () => [true, null],
    onlyElements: (children) => Array.isArray(children) ? children : [children],
    getChildKey: (child) => child.key,
    useMemo: (calculate, dependencies) => {
      const slot = next(() => ({}));
      if (!same(slot.dependencies, dependencies)) {
        slot.dependencies = dependencies;
        slot.value = calculate();
      }
      return slot.value;
    },
    useRef: (value) => next(() => ({ current: value })),
    useConstant: (initialize) => next(initialize),
    useState: (initial) => {
      const slot = next(() => ({ value: typeof initial === 'function' ? initial() : initial }));
      return [slot.value, (update) => {
        const value = typeof update === 'function' ? update(slot.value) : update;
        if (!Object.is(value, slot.value)) { slot.value = value; dirty = true; }
      }];
    },
    useContext: () => ({}),
    useIsomorphicLayoutEffect: (effect, dependencies) => {
      const slot = next(() => ({}));
      if (!dependencies || !same(slot.dependencies, dependencies)) {
        slot.dependencies = dependencies;
        effects.push(effect);
      }
    },
    process: { env: { NODE_ENV: 'production' } },
  };
  vm.createContext(context);
  vm.runInContext(`${source}\nglobalThis.controlledAnimatePresence = AnimatePresence;`, context);
  let props;
  let result;
  return {
    render(child) { props = { children: child, mode: 'wait' }; return this.rerender(); },
    rerender() {
      let iterations = 0;
      do {
        dirty = false;
        index = 0;
        result = context.controlledAnimatePresence(props);
        assert.ok(++iterations < 20, 'Unexpected render loop');
      } while (dirty);
      return result;
    },
    commit() { const pending = effects; effects = []; pending.forEach((effect) => effect()); },
    exit() { result.props.children[0].props.onExitComplete(); },
    get view() {
      return JSON.parse(JSON.stringify(result.props.children.map((child) => ({ key: child.key, present: child.props.isPresent }))));
    },
  };
}
const child = (key) => ({ key, props: { title: key } });
const controls = [];
for (const tool of ['masks', 'ai', 'crop']) {
  const normal = runtime();
  normal.render(child('presets')); normal.commit();
  normal.render(child(tool)); normal.commit();
  normal.exit(); normal.rerender(); normal.commit();
  assert.deepEqual(normal.view, [{ key: tool, present: true }]);
  controls.push({ name: `${tool}: callback after commit mounts latest child`, passed: true, view: normal.view });

  const early = runtime();
  early.render(child('presets')); early.commit();
  early.render(child(tool));
  early.exit(); // Deliberately before the parent layout effect registers the exit.
  early.commit();
  for (let repeat = 0; repeat < 5; repeat++) { early.rerender(); early.commit(); }
  assert.deepEqual(early.view, [{ key: 'presets', present: false }]);
  controls.push({ name: `${tool}: controlled early callback retains old child`, passed: true, view: early.view, laterRenders: 5 });

  // React key replacement creates a new component/hook instance. Delivering the
  // old completion to the old instance cannot mutate this new instance's slots.
  const replacement = runtime();
  replacement.render(child(tool)); replacement.commit();
  early.exit(); early.rerender(); early.commit();
  assert.deepEqual(replacement.view, [{ key: tool, present: true }]);
  controls.push({ name: `${tool}: new presence instance isolated from old callback`, passed: true, view: replacement.view });
}
const report = {
  status: 'passed',
  scope: 'Installed Framer Motion function under a deliberately controlled hook scheduler; no Windows, full App, real React scheduler, or native callback-order proof.',
  limitations: [
    'The early callback is explicitly scheduled by this control.',
    'This is not a claim that ordinary rapid switching always reproduces the native failure.',
    'PresenceChild and motion animation completion are represented by explicit callbacks.',
  ],
  packageVersion: JSON.parse(await readFile(resolve(repository, 'node_modules/framer-motion/package.json'), 'utf8')).version,
  source: { path: sourcePath, sha256: sha(original) },
  scriptSha256: sha(await readFile(fileURLToPath(import.meta.url))),
  controls,
};
await writeFile(resolve(directory, 'controlled-framer-report.json'), `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify({ status: report.status, controls: controls.length, report: resolve(directory, 'controlled-framer-report.json') }));
