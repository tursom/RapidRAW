import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const directory = dirname(fileURLToPath(import.meta.url));
const repository = process.env.TASK5_REPOSITORY ?? '/root/dev/work/tbt/RapidRAW';
const require = createRequire(resolve(repository, 'package.json'));
const ts = require('typescript');
const esbuild = require('esbuild');
const { chromium } = await import('/root/.npm/_npx/dd48173ecf795e2b/node_modules/playwright/index.mjs');
const sha = (value) => createHash('sha256').update(value).digest('hex');
const relative = 'src/components/panel/SidePanelArea.tsx';
const source = await readFile(resolve(repository, relative), 'utf8');
assert.equal(sha(source), 'ac9a543a95bfe39d5dccdd23de9dece7aaf86bc74e0a8e0c1ba59472c1be1bb3');
const comment = '          {/* Tool re-entry must not inherit an unfinished exit from the previous panel. */}\n';
const keyed = '<AnimatePresence key={historyFull && region === \'leftBottom\' ? activePanel : undefined} mode="wait">';
assert.equal(source.split(keyed).length, 2);
const base = source.replace(comment, '').replace(keyed, '<AnimatePresence mode="wait">');
assert.equal(sha(base), 'aedccbe50ec41e3757f2e957aff6b7e470862b44c0cfd99eb10596fa8f49fac1');
function declaration(text) {
  const parsed = ts.createSourceFile('SidePanelArea.tsx', text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  return parsed.statements.find((node) => ts.isFunctionDeclaration(node) && node.name?.text === 'RegionDroppableContainer').getText(parsed);
}
const appMode = await readFile(resolve(repository, 'src/utils/appMode.ts'), 'utf8');
const parsedMode = ts.createSourceFile('appMode.ts', appMode, ts.ScriptTarget.Latest, true);
const modeDeclaration = parsedMode.statements.find((node) => ts.isVariableStatement(node)).declarationList.declarations[0];
const modeExpression = modeDeclaration.initializer.getText(parsedMode);
const historyMode = new Function('useSettingsStore', `return (${modeExpression});`)({ getState: () => ({ osPlatform: 'windows' }) });
const keyExpression = "historyFull && region === 'leftBottom' ? activePanel : undefined";
const selectKey = new Function('historyFull', 'region', 'activePanel', `return (${keyExpression});`);
let matrixChecks = 0;
for (const platform of ['windows', 'macos', 'linux', 'android']) {
  for (const full of [false, true]) {
    for (const region of ['leftTop', 'leftBottom', 'rightTop', 'rightBottom']) {
      for (const panel of [null, 'presets', 'masks', 'ai', 'crop']) {
        const actual = selectKey(historyMode(platform) && full, region, panel);
        assert.equal(actual, platform !== 'android' && full && region === 'leftBottom' ? panel : undefined);
        matrixChecks++;
      }
    }
  }
}
const prefix = `
import React,{useState,useCallback,useRef,useLayoutEffect,useSyncExternalStore} from 'react';
import {createRoot} from 'react-dom/client';import {flushSync} from 'react-dom';
import {AnimatePresence,motion} from 'framer-motion';import clsx from 'clsx';
import {DndContext,useDroppable,useDndMonitor} from '@dnd-kit/core';
const subscribers=new Set();let current;let options;let nextInstance=0;
function setActivePanel(region,panel){current={...current,activePanels:{...current.activePanels,[region]:panel}};subscribers.forEach(fn=>fn());}
function useUIStore(select){return useSyncExternalStore(fn=>{subscribers.add(fn);return()=>subscribers.delete(fn)},()=>select(current));}
function useSettingsStore(select){return select({osPlatform:options.platform});}
useSettingsStore.getState=()=>({osPlatform:options.platform});
const isHistoryMode=${modeExpression};
const Panel={Metadata:'metadata',Export:'export'};const isModalPanel=p=>p==='metadata'||p==='export';
const COLLAPSE_THRESHOLD=200;const getReopenedPanelWidth=()=>300;
function PanelSwitcher(){return <div/>;}
`;
const suffix = `
function Content({name}){
 const instance=useRef(null);if(instance.current===null)instance.current=++nextInstance;
 const [count,setCount]=useState(0);
 useLayoutEffect(()=>{window.lifecycle.push({kind:'mount',name,instance:instance.current});return()=>window.lifecycle.push({kind:'unmount',name,instance:instance.current});},[]);
 return <section data-content={name} data-instance={instance.current} data-count={count}><h2>{name}</h2><button data-counter onClick={()=>setCount(n=>n+1)}>counter</button></section>;
}
function Test(){return <DndContext><div style={{width:300,height:300}}><RegionDroppableContainer region={options.region} side={options.region.startsWith('left')?'left':'right'} width={300} isInstantTransition={false} isResizing={false} renderPanel={name=><Content name={name}/>}/></div></DndContext>;}
window.initialize=next=>{
 if(window.reviewReactRoot)window.reviewReactRoot.unmount();options=next;
 const regions=['leftTop','leftBottom','rightTop','rightBottom'];
 current={panelLayout:Object.fromEntries(regions.map(r=>[r,['presets','masks','ai','crop']])),activePanels:Object.fromEntries(regions.map(r=>[r,'masks'])),setActivePanel,panelSwitcherPlacement:Object.fromEntries(regions.map(r=>[r,'bottom'])),setPanelSwitcherPlacement(){},isFullLayout:options.full};
 window.lifecycle=[];window.reviewReactRoot=createRoot(document.getElementById('root'));flushSync(()=>window.reviewReactRoot.render(<Test/>));
};
window.choose=name=>flushSync(()=>setActivePanel(options.region,name));
window.inspect=()=>{
 const panes=[];const visit=f=>{if(f.type===AnimatePresence&&f.memoizedProps?.mode==='wait')panes.push(f.key);for(let n=f.child;n;n=n.sibling)visit(n)};visit(window.reviewReactRoot._internalRoot.current);
 return {selected:current.activePanels[options.region],outer:document.querySelector('[data-panel]')?.getAttribute('data-panel'),presenceKeys:panes,content:[...document.querySelectorAll('[data-content]')].map(n=>({name:n.getAttribute('data-content'),instance:Number(n.getAttribute('data-instance')),count:Number(n.getAttribute('data-count'))})),lifecycle:[...window.lifecycle]};
};`;
const configurations = [
  { name: 'Windows fixed leftBottom', platform: 'windows', full: true, region: 'leftBottom' },
  { name: 'macOS fixed leftBottom', platform: 'macos', full: true, region: 'leftBottom' },
  { name: 'Linux fixed leftBottom', platform: 'linux', full: true, region: 'leftBottom' },
  { name: 'Android leftBottom unchanged', platform: 'android', full: true, region: 'leftBottom' },
  { name: 'desktop nonfixed leftBottom unchanged', platform: 'windows', full: false, region: 'leftBottom' },
  { name: 'desktop fixed leftTop unchanged', platform: 'windows', full: true, region: 'leftTop' },
  { name: 'desktop fixed rightTop unchanged', platform: 'windows', full: true, region: 'rightTop' },
  { name: 'desktop fixed rightBottom unchanged', platform: 'windows', full: true, region: 'rightBottom' },
];
const watched = [relative, ...JSON.parse(await readFile('/tmp/tbt-sessions-source-freeze.json', 'utf8')).files.map((row) => row.path), 'checks/tool-sessions/windows-smoke.py'];
async function hashes() { return Object.fromEntries(await Promise.all([...new Set(watched)].map(async (path) => [path, sha(await readFile(resolve(repository, path)))]))); }
const report = {
  scope: 'Actual extracted RegionDroppableContainer, project React, DndContext and Framer Motion in a minimal Linux Chromium page. Store/settings selectors and panel bodies are explicit local boundaries. Not Windows, full App, full SidePanelArea/mobile layout, or controller execution.',
  ordinaryRapidSwitchingAlwaysReproduces: false,
  source: { path: relative, sha256: sha(source), inversePatchSha256: sha(base), appModeSha256: sha(appMode) },
  platformKeyMatrixChecks: matrixChecks,
  before: await hashes(), rows: [], errors: [], cleanup: {},
};
let browser;
try {
  browser = await chromium.launch({ executablePath: '/root/.cache/ms-playwright/chromium-1254/chrome-linux64/chrome', headless: true, args: ['--no-sandbox'] });
  report.browserVersion = browser.version();
  for (const variant of ['before', 'candidate']) {
    const built = await esbuild.build({ stdin: { contents: prefix + declaration(variant === 'before' ? base : source) + suffix, sourcefile: 'memory-region.tsx', resolveDir: repository, loader: 'tsx' }, bundle: true, write: false, platform: 'browser', format: 'iife', jsx: 'automatic', define: { 'process.env.NODE_ENV': '"production"' }, logLevel: 'silent' });
    const page = await browser.newPage();
    page.on('pageerror', (error) => report.errors.push(String(error)));
    await page.setContent('<div id="root"></div>');
    await page.addScriptTag({ content: built.outputFiles[0].text });
    for (const configuration of configurations) {
      const keyedScope = configuration.platform !== 'android' && configuration.full && configuration.region === 'leftBottom';
      const keyedCandidate = variant === 'candidate' && keyedScope;
      await page.evaluate((options) => window.initialize(options), configuration);
      await page.waitForTimeout(220);
      await page.locator('[data-counter]').click();
      const before = await page.evaluate(() => window.inspect());
      assert.equal(before.content.length, 1); assert.equal(before.content[0].name, 'masks'); assert.equal(before.content[0].count, 1);
      await page.evaluate(() => window.choose('presets'));
      const presetsImmediate = await page.evaluate(() => window.inspect());
      if (keyedCandidate) {
        assert.equal(presetsImmediate.content.length, 1);
        assert.equal(presetsImmediate.content[0].name, 'presets');
        assert.ok(presetsImmediate.lifecycle.some((event) => event.kind === 'unmount' && event.instance === before.content[0].instance));
        assert.deepEqual(presetsImmediate.presenceKeys, ['presets']);
      } else {
        assert.deepEqual(presetsImmediate.presenceKeys, [null]);
      }
      // A deliberately short, controlled interval. We don't assert that the
      // pre-patch implementation must get stuck under this ordinary schedule.
      await page.waitForTimeout(20);
      await page.evaluate(() => window.choose('masks'));
      const reentryImmediate = await page.evaluate(() => window.inspect());
      if (keyedCandidate) {
        assert.equal(reentryImmediate.content.length, 1); assert.equal(reentryImmediate.content[0].name, 'masks');
        assert.notEqual(reentryImmediate.content[0].instance, before.content[0].instance);
        assert.equal(reentryImmediate.content[0].count, 0);
        assert.deepEqual(reentryImmediate.presenceKeys, ['masks']);
      }
      await page.waitForTimeout(350);
      const settled = await page.evaluate(() => window.inspect());
      assert.equal(settled.outer, 'masks'); assert.equal(settled.content.length, 1); assert.equal(settled.content[0].name, 'masks');
      if (!keyedCandidate) {
        assert.equal(settled.content[0].instance, before.content[0].instance, 'Unchanged scope retains its ordinary re-entry instance');
        assert.equal(settled.content[0].count, 1);
      }
      await page.locator('[data-counter]').click();
      const sameKeyBefore = await page.evaluate(() => window.inspect());
      await page.evaluate(() => window.choose('masks'));
      const sameKeyAfter = await page.evaluate(() => window.inspect());
      assert.deepEqual(sameKeyAfter.content, sameKeyBefore.content);
      assert.deepEqual(sameKeyAfter.lifecycle, sameKeyBefore.lifecycle);
      if (keyedCandidate) {
        for (const panel of ['presets', 'ai', 'presets', 'crop', 'masks']) {
          await page.evaluate((name) => window.choose(name), panel);
          const current = await page.evaluate(() => window.inspect());
          assert.equal(current.content.length, 1); assert.equal(current.content[0].name, panel);
          assert.deepEqual(current.presenceKeys, [panel]);
        }
        await page.waitForTimeout(250);
        const afterLateCallbacks = await page.evaluate(() => window.inspect());
        assert.equal(afterLateCallbacks.content.length, 1); assert.equal(afterLateCallbacks.content[0].name, 'masks');
      }
      report.rows.push({ variant, configuration, keyedCandidate, before, presetsImmediate, reentryImmediate, settled, sameKeyBefore, sameKeyAfter, passed: true });
    }
    await page.close();
  }
  assert.deepEqual(report.errors, []);
  report.status = 'passed';
} catch (error) {
  report.status = 'failed'; report.errors.push(error.stack ?? String(error));
} finally {
  await browser?.close(); report.cleanup.browserClosed = true;
  esbuild.stop(); report.cleanup.esbuildStopped = true;
  report.after = await hashes();
  report.sourceUnchanged = JSON.stringify(report.before) === JSON.stringify(report.after);
  if (!report.sourceUnchanged) report.status = 'failed';
  report.scriptSha256 = sha(await readFile(fileURLToPath(import.meta.url)));
  await writeFile(resolve(directory, 'lifecycle-report.json'), `${JSON.stringify(report, null, 2)}\n`);
}
console.log(JSON.stringify({ status: report.status, platformKeyMatrixChecks: matrixChecks, runtimeRows: report.rows.length, sourceUnchanged: report.sourceUnchanged, errors: report.errors, report: resolve(directory, 'lifecycle-report.json') }));
if (report.status !== 'passed') process.exitCode = 1;
