"""Read-only production verification; writes review evidence only beside this script."""
import ast
import hashlib
import json
import pathlib
import subprocess

HERE = pathlib.Path(__file__).resolve().parent
REPOSITORY = pathlib.Path('/root/dev/work/tbt/RapidRAW')
SOURCE = REPOSITORY / 'src/components/panel/SidePanelArea.tsx'
EXPECTED = 'ac9a543a95bfe39d5dccdd23de9dece7aaf86bc74e0a8e0c1ba59472c1be1bb3'
BASE = 'aedccbe50ec41e3757f2e957aff6b7e470862b44c0cfd99eb10596fa8f49fac1'
CONTROLLER = 'f63dce3716862e824cb0a2713e31ab5083dcb9e0c3e2d05d0c711afbd3d29cf1'
sha = lambda data: hashlib.sha256(data).hexdigest()
source = SOURCE.read_bytes()
assert sha(source) == EXPECTED
comment = b'          {/* Tool re-entry must not inherit an unfinished exit from the previous panel. */}\n'
keyed = b'<AnimatePresence key={historyFull && region === \'leftBottom\' ? activePanel : undefined} mode="wait">'
assert source.count(comment) == source.count(keyed) == 1
assert sha(source.replace(comment, b'').replace(keyed, b'<AnimatePresence mode="wait">')) == BASE
manifests = []
for name in ['tbt-sessions-source-freeze.json', 'tbt-sessions-inputs.json']:
    path = pathlib.Path('/tmp') / name
    raw = path.read_bytes()
    manifest = json.loads(raw)
    for row in manifest['files']:
        assert sha((REPOSITORY / row['path']).read_bytes()) == row['sha256'], row['path']
    manifests.append({'path': str(path), 'sha256': sha(raw), 'files': len(manifest['files']), 'matched': True})
assert manifests[0]['files'] == 8 and manifests[1]['files'] == 417
prettier = subprocess.run([str(REPOSITORY / 'node_modules/.bin/prettier'), '--check', 'src/components/panel/SidePanelArea.tsx'], cwd=REPOSITORY, capture_output=True)
(HERE / 'prettier.stdout.txt').write_bytes(prettier.stdout)
(HERE / 'prettier.stderr.txt').write_bytes(prettier.stderr)
assert prettier.returncode == 0
lint = subprocess.run([str(REPOSITORY / 'node_modules/.bin/eslint'), 'src/components/panel/SidePanelArea.tsx', '--format', 'json'], cwd=REPOSITORY, capture_output=True)
(HERE / 'eslint.json').write_bytes(lint.stdout)
(HERE / 'eslint.stderr.txt').write_bytes(lint.stderr)
records = json.loads(lint.stdout)
messages = [message for row in records for message in row['messages']]
comparison = json.loads(pathlib.Path('/tmp/tbt-task5-panel-lint.json').read_bytes())
normalized = [{key: row[key] for key in ['ruleId', 'severity', 'message', 'messageId']} for row in messages]
assert normalized == comparison['before']['messages'] == comparison['after']['messages']
assert sum(row['errorCount'] for row in records) == 2 and sum(row['warningCount'] for row in records) == 0
controller_path = REPOSITORY / 'checks/tool-sessions/windows-smoke.py'
controller_bytes = controller_path.read_bytes()
assert sha(controller_bytes) == CONTROLLER
namespace = {'__name__': 'readonly_verifier', '__file__': str(controller_path)}
exec(compile(ast.parse(controller_bytes), str(controller_path), 'exec'), namespace)
assert len(namespace['GROUPS']) == 12
assert sum(map(len, namespace['expected_cases']().values())) == 108
assert len(namespace['BROWSER_REQUIRED']) == 14
assert b'len(report["canonicalScreenshots"]) == 3' in controller_bytes
hook = json.loads((HERE / 'controlled-framer-report.json').read_bytes())
lifecycle = json.loads((HERE / 'lifecycle-report.json').read_bytes())
assert hook['status'] == lifecycle['status'] == 'passed'
assert len(hook['controls']) == 9 and lifecycle['platformKeyMatrixChecks'] == 160 and len(lifecycle['rows']) == 16
assert lifecycle['sourceUnchanged'] and not lifecycle['errors']
assert sha(SOURCE.read_bytes()) == EXPECTED
report = {
    'status': 'SOURCE_FREEZE_PASS',
    'scope': 'Read-only independent source/isolated-control review; no Windows, production edits, complete browser run, release build, or native runtime validation.',
    'source': {'path': str(SOURCE), 'sha256': EXPECTED, 'bytes': len(source), 'inversePatchSha256': BASE, 'delta': 'One comment and one conditional AnimatePresence key; all remaining file bytes identical.'},
    'manifests': manifests,
    'controller': {'sha256': CONTROLLER, 'groups': 12, 'nativeCases': 108, 'browserContractCases': 14, 'requiredCaptures': 3, 'unchanged': True},
    'prettier': {'exit': prettier.returncode},
    'scopedESLint': {'exit': lint.returncode, 'errors': 2, 'warnings': 0, 'addedDiagnostics': [], 'basis': '/tmp/tbt-task5-panel-lint.json', 'messages': normalized},
    'controls': {'controlledActualFramerFunction': 9, 'platformLayoutRegionKeyMatrix': 160, 'actualExtractedRegionReactLifecycle': 16},
    'limits': [
        'Early exit-before-parent-layout ordering is explicitly controlled, not measured from native runtime.',
        'Ordinary rapid switching is not claimed to reproduce the native failure on every run.',
        'Lifecycle controls use the real extracted region and installed React/Framer/DndContext, with explicit store/settings and panel-body boundaries.',
        'Android scope validation proves conditional key isolation, not Android hardware behavior.',
        'Full real SidePanelArea/browser regressions and rebuilt Windows verification remain parent/browser-owner work.'
    ],
}
(HERE / 'source-review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'sourceSha256': EXPECTED, 'sourceFiles': 8, 'buildInputs': 417, 'prettierExit': prettier.returncode, 'scopedESLintErrors': 2, 'scopedESLintAdded': 0, 'controls': report['controls']}))
