import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const directory=dirname(fileURLToPath(import.meta.url));
const repository='/root/dev/work/tbt/RapidRAW';
const require=createRequire(`${repository}/package.json`);
const {build,stop}=require('esbuild');
const {chromium}=await import('/root/.npm/_npx/dd48173ecf795e2b/node_modules/playwright/index.mjs');
const executablePath='/root/.cache/ms-playwright/chromium-1254/chrome-linux64/chrome';
const sha=value=>createHash('sha256').update(value).digest('hex');
const watched=[
 'src/components/ui/Button.tsx','src/hooks/useKeyboardShortcuts.ts','checks/tool-sessions/windows-smoke.py',
 'checks/tool-sessions/evidence/browser/chromium.json.gz','checks/tool-sessions/evidence/browser/browser-manifest.json',
 'checks/tool-sessions/evidence/browser/native-supplement.json',
];
async function fingerprints(){const result={};for(const file of watched)result[file]=sha(await readFile(resolve(repository,file)));return result;}
const report={schema:1,scope:'Temporary minimal Linux Chromium page only; not Windows WebView2, full App, tool-session fixture or final suite',
 startedAt:new Date().toISOString(),directory,source:{realProductionButton:true,realKeyboardHookMounted:false,
 note:'Production Button imported unchanged; simple native button alongside it. No page key prevention except explicit negative controls.'},
 before:await fingerprints(),cases:[],errors:[],cleanup:{}};
const entry=`import React from ${JSON.stringify(`${repository}/node_modules/react/index.js`)};
import {createRoot} from ${JSON.stringify(`${repository}/node_modules/react-dom/client.js`)};
import Button from ${JSON.stringify(`${repository}/src/components/ui/Button.tsx`)};
createRoot(document.getElementById('production-root')).render(React.createElement(Button,{
 id:'production',type:'button',disabled:false,className:'bg-surface','data-tool-session-action':'cancel',
 onClick:event=>window.record('buttonHandler',{button:'production',trusted:event.nativeEvent.isTrusted})
},'Production Cancel'));
window.productionBundleLoaded=true;`;
await writeFile(resolve(directory,'entry.tsx'),entry);
const bundle=await build({stdin:{contents:entry,sourcefile:resolve(directory,'entry.tsx'),resolveDir:repository,loader:'tsx'},
 absWorkingDir:directory,nodePaths:[`${repository}/node_modules`],bundle:true,platform:'browser',format:'iife',jsx:'automatic',
 jsxImportSource:'react',define:{'process.env.NODE_ENV':'"production"'},write:false,outfile:resolve(directory,'bundle.js'),logLevel:'silent'});
await writeFile(resolve(directory,'bundle.js'),bundle.outputFiles[0].contents);
report.source.bundleSha256=sha(bundle.outputFiles[0].contents);
const enter={key:'Enter',code:'Enter',windowsVirtualKeyCode:13,nativeVirtualKeyCode:13,modifiers:0};
const tab={key:'Tab',code:'Tab',windowsVirtualKeyCode:9,nativeVirtualKeyCode:9,modifiers:0};
const space={key:' ',code:'Space',windowsVirtualKeyCode:32,nativeVirtualKeyCode:32,modifiers:0};
const variants=[
 {name:'exact-keyDown-keyUp-no-text',events:[{type:'keyDown',...enter},{type:'keyUp',...enter}]},
 {name:'keyDown-text-CR-only',events:[{type:'keyDown',...enter,text:'\r'},{type:'keyUp',...enter}]},
 {name:'keyDown-text-and-unmodifiedText-CR',events:[{type:'keyDown',...enter,text:'\r',unmodifiedText:'\r'},{type:'keyUp',...enter}]},
 {name:'keyDown-char-CR-keyUp',events:[{type:'keyDown',...enter},{type:'char',...enter,text:'\r',unmodifiedText:'\r'},{type:'keyUp',...enter}]},
 {name:'char-CR-only',events:[{type:'char',...enter,text:'\r',unmodifiedText:'\r'}]},
 {name:'space-no-text-positive-control',events:[{type:'keyDown',...space},{type:'keyUp',...space}]},
];
let browser;
try{
 browser=await chromium.launch({executablePath,headless:true,args:['--no-sandbox']});
 report.environment={browserVersion:browser.version(),executablePath,platform:process.platform};
 async function run(target,variant,repeat,blockEnter=false){
  const row={target,variant:variant.name,repeat,blockEnter,commands:[]};report.cases.push(row);
  const page=await browser.newPage({viewport:{width:800,height:400}});
  page.on('pageerror',error=>report.errors.push({target,variant:variant.name,error:String(error)}));
  const cdp=await page.context().newCDPSession(page);
  const frames=()=>page.evaluate(()=>new Promise(done=>requestAnimationFrame(()=>requestAnimationFrame(done))));
  const send=async(params,phase)=>{
   const command={method:'Input.dispatchKeyEvent',phase,params,startedAt:new Date().toISOString()};row.commands.push(command);
   command.response=await cdp.send(command.method,params);
  };
  try{
   await page.goto(pathToFileURL(resolve(directory,'index.html')).href);
   await page.waitForSelector('#production');await page.bringToFront();await frames();
   await page.evaluate(()=>{window.phase='trusted-tab-focus';});
   for(let index=0;index<(target==='production'?2:1);index++){
    await send({type:'keyDown',...tab},'trusted-tab-focus');await send({type:'keyUp',...tab},'trusted-tab-focus');await frames();
   }
   row.focusBefore=await page.evaluate(()=>({id:document.activeElement?.id,tag:document.activeElement?.tagName,hasFocus:document.hasFocus()}));
   assert.equal(row.focusBefore.id,target);assert.equal(row.focusBefore.tag,'BUTTON');assert.equal(row.focusBefore.hasFocus,true);
   row.focusTrace=await page.evaluate(()=>window.events.slice());
   await page.evaluate(block=>{window.blockEnter=block;window.phase='measurement';},blockEnter);
   for(const event of variant.events)await send(event,'measurement');
   await frames();
   row.events=await page.evaluate(()=>window.events.filter(event=>event.phase==='measurement'));
   row.completeRawEvents=await page.evaluate(()=>window.events.slice());
   row.focusAfter=await page.evaluate(()=>({id:document.activeElement?.id,hasFocus:document.hasFocus()}));
   row.nativeClicks=row.events.filter(event=>event.kind==='event'&&event.listener==='capture'&&event.type==='click');
   row.keypresses=row.events.filter(event=>event.kind==='event'&&event.listener==='capture'&&event.type==='keypress');
   row.handlers=row.events.filter(event=>event.kind==='buttonHandler');
   assert.ok(row.events.filter(event=>event.kind==='event').every(event=>event.trusted===true));
   assert.equal(row.focusAfter.id,target);
   row.status='completed';
   console.log(JSON.stringify({target,variant:variant.name,repeat,blockEnter,trustedClicks:row.nativeClicks.length,keypresses:row.keypresses.length,handlers:row.handlers.length}));
  }catch(error){row.status='failed';row.error=error.stack??String(error);throw error;}
  finally{await cdp.detach();await page.close();}
 }
 for(const target of ['native','production'])for(const variant of variants)for(let repeat=1;repeat<=3;repeat++)await run(target,variant,repeat);
 for(const target of ['native','production'])await run(target,variants[2],1,true);
}catch(error){report.errors.push({kind:'runner',error:error.stack??String(error)});}
finally{
 await browser?.close();report.cleanup.browserClosed=true;stop();report.cleanup.esbuildStopped=true;
 report.after=await fingerprints();report.repositoryFilesUnchanged=JSON.stringify(report.before)===JSON.stringify(report.after);
 report.finishedAt=new Date().toISOString();
}
report.summary=report.cases.map(row=>({target:row.target,variant:row.variant,repeat:row.repeat,blockEnter:row.blockEnter,
 status:row.status,focusBefore:row.focusBefore,trustedClicks:row.nativeClicks?.length,keypresses:row.keypresses?.length,handlers:row.handlers?.length}));
report.status=report.errors.length||!report.repositoryFilesUnchanged?'failed':'completed';
await writeFile(resolve(directory,'raw.json'),`${JSON.stringify(report,null,2)}\n`);
console.log(JSON.stringify({status:report.status,report:resolve(directory,'raw.json'),cases:report.cases.length,repositoryFilesUnchanged:report.repositoryFilesUnchanged,errors:report.errors}));
if(report.status==='failed')process.exitCode=1;
