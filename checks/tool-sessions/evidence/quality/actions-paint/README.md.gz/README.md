The native visual audit remains VISUAL_P2_CONFIRMED_BLOCKING. Native5's automated 108/108 result is not a visual or publication pass.

The three original owned-client captures were read directly. Their SHA256 values match windows-smoke.json. Each recorded actions band (316,448)-(944,504) contains exactly 35,168 pixels of RGB(35,35,35), with no painted button background or text. The parent moved the original download into /tmp/tbt-sessions-build3-visual-rejected-download during this review; audit-native.py accepts an alternative input directory as its first argument. It does not modify those PNGs or native report.

css-paint-control.mjs uses the real baseline ToolSessionActions (d88d1429e1e34a29aa3e2fd23f1219a54cf8a9e848f108f70972ddf57ea05c4e), real Button, and generated Tailwind CSS (ece510f1382e1bb5fbe48c7d1fcaa1a22701dd11779a8d81cca311536770ab48). The Editor sibling layout is a minimal HTML reconstruction. Stores, busy state, actions and translation are explicit local boundaries. No WGPU or ImageCanvas is present. Production files are never written.

Four in-memory variants isolate the cause:

- ring + original static actions: no button pixels, but both hit tests and trusted click handlers succeed;
- ring + actions relative z-10: both buttons paint, all bar/button rectangles remain identical;
- no ring + original static actions: both buttons paint;
- restore ring + original static actions: buttons disappear again while trusted clicks still succeed.

This confirms a CSS painting failure independent of WGPU. The viewport's isolate stacking context and 9999px ring shadow paint above the unpositioned actions sibling. Box shadow does not intercept hit testing. Putting the actions row in relative z-10 places it above that viewport context, matching the existing toolbar treatment.

The control is deliberately not a full Editor, Windows/WebView2 or final visual acceptance. Its palette and font are explicit, and its screenshots are only local control screenshots, never replacement native evidence. Final acceptance must read fresh real owned-client PNGs from the rebuilt executable after the production class fix.

Files: report.json contains computed CSS, DOM rectangles, hit-test results, trusted events, hashes and pixel comparisons. native-screenshot-audit.json binds the actual failed native captures. The four named PNGs show the local controls. archive-manifest.json binds this temporary review directory for explicit archiving.
