import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { readFile, writeFile, readdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const directory = dirname(fileURLToPath(import.meta.url));
const repository = '/root/dev/work/tbt/RapidRAW';
const require = createRequire(resolve(repository, 'package.json'));
const esbuild = require('esbuild');
const { chromium } = await import('/root/.npm/_npx/dd48173ecf795e2b/node_modules/playwright/index.mjs');
const sha = (value) => createHash('sha256').update(value).digest('hex');
const actionsPath = resolve(repository, 'src/components/panel/editor/ToolSessionActions.tsx');
const liveActions = await readFile(actionsPath, 'utf8');
const className = 'className="shrink-0 flex justify-center gap-3 py-2"';
const raisedClassName = 'className="relative z-10 shrink-0 flex justify-center gap-3 py-2"';
// Support rerunning after the parent applies precisely the reviewed class fix.
// Reconstruct only that exact baseline in memory; never edit the production file.
const actions = liveActions.includes(raisedClassName) ? liveActions.replace(raisedClassName, className) : liveActions;
assert.equal(actions.split(className).length, 2);
assert.equal(sha(actions), 'd88d1429e1e34a29aa3e2fd23f1219a54cf8a9e848f108f70972ddf57ea05c4e');
const candidate = actions.replace(className, raisedClassName);
const cssName = (await readdir(resolve(repository, 'dist/assets'))).find((name) => name.endsWith('.css'));
const cssPath = resolve(repository, 'dist/assets', cssName);
const css = await readFile(cssPath, 'utf8');
assert.ok(css.includes('.ring-\\[9999px\\]'));
const variants = [
  { name: 'ring-static-before', ring: true, candidate: false },
  { name: 'ring-actions-relative-z10', ring: true, candidate: true },
  { name: 'no-ring-static-control', ring: false, candidate: false },
  { name: 'ring-restored-negative', ring: true, candidate: false },
];
const report = {
  scope: 'Minimal Linux Chromium CSS paint control. Real unchanged ToolSessionActions/Button and generated project Tailwind CSS; explicit settings/store/busy/actions/translation boundaries. No WGPU, canvas, full Editor, Windows, source edits, or native screenshot synthesis.',
  liveActionsSourceSha256: sha(liveActions),
  actionsSourceSha256: sha(actions),
  candidateInMemorySha256: sha(candidate),
  generatedCss: { path: cssPath, sha256: sha(css) },
  variants: [], errors: [],
};
let browser;
try {
  browser = await chromium.launch({ executablePath: '/root/.cache/ms-playwright/chromium-1254/chrome-linux64/chrome', headless: true, args: ['--no-sandbox'] });
  report.browserVersion = browser.version();
  for (const variant of variants) {
    const plugin = {
      name: 'explicit-css-control-boundaries',
      setup(build) {
        build.onResolve({ filter: /useEditorStore$|useProcessStore$|useSettingsStore$|useUIStore$|useEditorActions$|^react-i18next$/ }, () => ({ path: 'boundary', namespace: 'boundary' }));
        build.onLoad({ filter: /.*/, namespace: 'boundary' }, () => ({
          contents: `const editor={selectedImage:{path:'CSS-only.NEF',isReady:true},isGeneratingAi:false,isGeneratingAiMask:false,adjustments:{masks:[],aiPatches:[]}};export const useEditorStore=s=>s(editor),useProcessStore=s=>s({activeAiTasks:{}}),useSettingsStore=s=>s({osPlatform:'windows'}),useUIStore=s=>s({activePanel:'crop'});export const toolSessionBusy=()=>false;export const applyToolSession=()=>window.handlers.push('apply'),cancelToolSession=()=>window.handlers.push('cancel');export function useTranslation(){return{t:key=>key.endsWith('apply')?'Apply':'Cancel'}}`,
          loader: 'js', resolveDir: repository,
        }));
        build.onLoad({ filter: /ToolSessionActions\.tsx$/ }, () => ({ contents: variant.candidate ? candidate : actions, loader: 'tsx', resolveDir: dirname(actionsPath) }));
      },
    };
    const entry = `import React from 'react';import{createRoot}from'react-dom/client';import{flushSync}from'react-dom';import ToolSessionActions from './src/components/panel/editor/ToolSessionActions';window.handlers=[];window.inputs=[];document.addEventListener('click',event=>window.inputs.push({trusted:event.isTrusted,action:event.target.closest('[data-tool-session-action]')?.getAttribute('data-tool-session-action')}),true);flushSync(()=>createRoot(document.getElementById('actions-host')).render(<ToolSessionActions/>));`;
    const built = await esbuild.build({ stdin: { contents: entry, loader: 'tsx', sourcefile: 'css-only.tsx', resolveDir: repository }, bundle: true, platform: 'browser', format: 'iife', write: false, jsx: 'automatic', define: { 'process.env.NODE_ENV': '"production"' }, plugins: [plugin], logLevel: 'silent' });
    const page = await browser.newPage({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: 1 });
    page.on('pageerror', (error) => report.errors.push(String(error)));
    await page.setContent(`<style>${css}</style><style>:root{--app-bg-secondary:rgb(35,35,35);--app-surface:rgb(60,60,60);--app-accent:rgb(255,255,255);--app-button-text:rgb(0,0,0);--font-family:Arial}body{margin:0;background:rgb(24,24,24)}#editor{position:absolute;left:308px;top:56px;width:644px;height:456px}#toolbar{height:48px;background:rgb(60,60,60);color:white}#viewport{background:rgb(110,130,150)}#actions-host{display:contents}</style><main id="editor" class="flex flex-col relative overflow-hidden rounded-lg p-2 gap-2"><header id="toolbar" class="shrink-0 relative z-10">Actual stacking control toolbar</header><div id="viewport" class="flex-1 flex relative overflow-hidden isolate rounded-lg ${variant.ring ? 'ring-[9999px] ring-bg-secondary' : ''}">CSS viewport placeholder; no WGPU</div><div id="actions-host"></div></main>`);
    await page.addScriptTag({ content: built.outputFiles[0].text });
    await page.evaluate(() => document.fonts.ready);
    await page.evaluate(() => new Promise((done) => requestAnimationFrame(() => requestAnimationFrame(done))));
    const observed = await page.evaluate(() => {
      const bar = document.querySelector('[data-tool-session-actions]');
      const viewport = document.getElementById('viewport');
      const styles = (node) => { const s = getComputedStyle(node); return { position: s.position, zIndex: s.zIndex, isolation: s.isolation, boxShadow: s.boxShadow, backgroundColor: s.backgroundColor, display: s.display }; };
      return { bar: { rect: bar.getBoundingClientRect().toJSON(), styles: styles(bar) }, viewport: { rect: viewport.getBoundingClientRect().toJSON(), styles: styles(viewport) }, buttons: [...bar.querySelectorAll('button')].map((button) => { const r = button.getBoundingClientRect(); const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return { action: button.getAttribute('data-tool-session-action'), rect: r.toJSON(), styles: styles(button), hitMatches: hit === button || button.contains(hit), disabled: button.disabled }; }) };
    });
    assert.equal(observed.bar.rect.x, 316); assert.equal(observed.bar.rect.y, 448);
    assert.equal(observed.bar.rect.width, 628); assert.equal(observed.bar.rect.height, 56);
    assert.equal(observed.viewport.styles.isolation, 'isolate');
    assert.ok(variant.ring ? observed.viewport.styles.boxShadow.includes('9999px') : observed.viewport.styles.boxShadow === 'none');
    assert.ok(observed.buttons.every((button) => button.hitMatches && !button.disabled));
    const pngPath = resolve(directory, `${variant.name}.png`);
    const png = await page.screenshot({ path: pngPath });
    for (const action of ['apply', 'cancel']) await page.locator(`[data-tool-session-action="${action}"]`).click();
    const interactions = await page.evaluate(() => ({ handlers: window.handlers, inputs: window.inputs }));
    assert.deepEqual(interactions.handlers, ['apply', 'cancel']);
    assert.ok(interactions.inputs.length === 2 && interactions.inputs.every((event) => event.trusted));
    report.variants.push({ ...variant, observed, interactions, screenshot: { path: pngPath, sha256: sha(png), bytes: png.length } });
    await page.close();
  }
  const before = report.variants[0].observed;
  for (const variant of report.variants) {
    assert.deepEqual(variant.observed.bar.rect, before.bar.rect);
    assert.deepEqual(variant.observed.buttons.map((button) => button.rect), before.buttons.map((button) => button.rect));
  }
  const pixelControl = spawnSync('python', ['-c', `import json,sys,math\nfrom PIL import Image\nr=json.load(sys.stdin);out=[]\nfor v in r['variants']:\n im=Image.open(v['screenshot']['path']).convert('RGB');bar=im.crop((316,448,944,504));bg=(35,35,35);pixels=list(bar.getdata());buttons=[]\n for b in v['observed']['buttons']:\n  q=b['rect'];crop=im.crop((math.ceil(q['left'])+2,math.ceil(q['top'])+2,math.floor(q['right'])-2,math.floor(q['bottom'])-2));values=list(crop.getdata());buttons.append({'action':b['action'],'nonBackgroundPixels':sum(p!=bg for p in values),'pixels':len(values)})\n visible=v['candidate'] or not v['ring'];assert all((b['nonBackgroundPixels']>0)==visible for b in buttons),(v['name'],buttons)\n assert (len(set(pixels))>1)==visible\n out.append({'name':v['name'],'barUniqueColors':len(set(pixels)),'barNonBackgroundPixels':sum(p!=bg for p in pixels),'buttons':buttons,'paintedAsExpected':True})\nprint(json.dumps(out))`], { input: JSON.stringify(report), encoding: 'utf8' });
  assert.equal(pixelControl.status, 0, pixelControl.stderr);
  report.pixelControls = JSON.parse(pixelControl.stdout);
  assert.deepEqual(report.errors, []);
  assert.equal(sha(await readFile(actionsPath)), sha(liveActions));
  assert.equal(sha(await readFile(cssPath)), report.generatedCss.sha256);
  report.sourceAndCssUnchanged = true;
  report.status = 'passed';
} catch (error) {
  report.status = 'failed'; report.errors.push(error.stack ?? String(error));
} finally {
  await browser?.close(); esbuild.stop();
  report.cleanup = { browserClosed: true, esbuildStopped: true };
  report.scriptSha256 = sha(await readFile(fileURLToPath(import.meta.url)));
  await writeFile(resolve(directory, 'report.json'), `${JSON.stringify(report, null, 2)}\n`);
}
console.log(JSON.stringify({ status: report.status, variants: report.variants.length, pixels: report.pixelControls, errors: report.errors, report: resolve(directory, 'report.json') }, null, 2));
if (report.status !== 'passed') process.exitCode = 1;
