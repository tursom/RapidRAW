import React from 'react';
import { createRoot } from 'react-dom/client';
import { flushSync } from 'react-dom';
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { mockIPC, mockWindows } from '@tauri-apps/api/mocks';
import { useAiMasking } from '/root/dev/work/tbt/RapidRAW/src/hooks/useAiMasking';
import { useAiMasking as useLegacyAiMasking } from 'virtual:before-ai-hook';
import { useAiMasking as usePreReviewAiMasking } from 'virtual:pre-review-ai-hook';
import { useAiMasking as usePreOrphanAiMasking } from 'virtual:pre-orphan-ai-hook';
import { useEditorStore } from '/root/dev/work/tbt/RapidRAW/src/store/useEditorStore';
import { useProcessStore } from '/root/dev/work/tbt/RapidRAW/src/store/useProcessStore';
import { useCloudStore } from '/root/dev/work/tbt/RapidRAW/src/store/useCloudStore';
import { useSettingsStore } from '/root/dev/work/tbt/RapidRAW/src/store/useSettingsStore';
import { INITIAL_ADJUSTMENTS, normalizeLoadedAdjustments } from '/root/dev/work/tbt/RapidRAW/src/utils/adjustments';
import { debouncedSetHistory, debouncedSave, toolSessionBusy, cancelToolSession } from '/root/dev/work/tbt/RapidRAW/src/hooks/useEditorActions';
import { useUIStore } from '/root/dev/work/tbt/RapidRAW/src/store/useUIStore';
import { globalImageCache } from '/root/dev/work/tbt/RapidRAW/src/utils/ImageLRUCache';
import { useImageLoader } from '/root/dev/work/tbt/RapidRAW/src/hooks/useImageLoader';

function deferred() {
  let resolve!: (value: any) => void, reject!: (error: any) => void;
  const promise = new Promise<any>((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}
const ipc: any[] = [], tokens: any[] = [], traces: any[] = [], results: any[] = [];
let usageCalls = 0, checks = 0, cancelFailure = false, heldCancel: ReturnType<typeof deferred> | null = null;
const tokenGetter = () => { const row = deferred(); tokens.push(row); return row.promise; };
useCloudStore.setState({ getToken: tokenGetter, fetchUsage: async () => { usageCalls++; } });
mockWindows('main');
mockIPC((cmd, args) => {
  traces.push({ cmd, args });
  if (cmd === 'cancel_ai_task') return heldCancel ? heldCancel.promise : cancelFailure ? Promise.reject(new Error('cancel mock failure')) : null;
  if (cmd === 'save_metadata_and_update_thumbnail' || cmd === 'save_settings') return null;
  const row = { cmd, args, ...deferred() }; ipc.push(row); return row.promise;
});
await i18n.use(initReactI18next).init({ lng: 'en', fallbackLng: 'en', resources: { en: { translation: {} } }, interpolation: { escapeValue: false } });
const cacheRef = { current: null as any };
let current: ReturnType<typeof useAiMasking>, other: ReturnType<typeof useAiMasking>, legacy: ReturnType<typeof useAiMasking>, preReview: ReturnType<typeof useAiMasking>, preOrphan: ReturnType<typeof useAiMasking>;
function Host() {
  current = useAiMasking(); other = useAiMasking(); legacy = useLegacyAiMasking(); preReview = usePreReviewAiMasking(); preOrphan = usePreOrphanAiMasking();
  useImageLoader(cacheRef);
  return null;
}
const root = createRoot(document.getElementById('root')!);
const tick = async () => { for (let i = 0; i < 12; i++) await Promise.resolve(); };
function check(ok: any, message: string) { checks++; if (!ok) throw new Error(message); }
function equal(a: any, b: any, message: string) { check(JSON.stringify(a) === JSON.stringify(b), `${message}: ${JSON.stringify(a)} != ${JSON.stringify(b)}`); }
const editor = () => useEditorStore.getState();
const tasks = () => useProcessStore.getState().activeAiTasks;
const patch = () => editor().adjustments.aiPatches[0];
const busy = () => toolSessionBusy(editor(), useProcessStore.getState());
function adjustments() {
  const sub = { id: 's', type: 'brush', mode: 'additive', visible: true, opacity: 100, parameters: { parts: ['skin'], old: 'original', lines: [] } };
  return { ...structuredClone(INITIAL_ADJUSTMENTS), masks: [{ id: 'm', name: 'Mask', visible: true, invert: false, opacity: 100, adjustments: {}, subMasks: [structuredClone(sub)] }], aiPatches: [{ id: 'p', name: 'Original', visible: true, invert: false, isLoading: false, prompt: '', patchData: { original: true }, subMasks: [structuredClone({ ...sub, id: 'ps' })] }] } as any;
}
function select(path = 'A', adj = adjustments()) {
  flushSync(() => {
    editor().setEditor({ selectedImage: { path, isReady: true, width: 100, height: 100 } as any, adjustments: adj,
      finalPreviewUrl: 'data:,preview', hasRenderedFirstFrame: true, activeAiPatchContainerId: 'p', activeAiSubMaskId: 'ps',
      activeMaskContainerId: null, activeMaskId: null, patchesSentToBackend: new Set(), isGeneratingAi: false, isGeneratingAiMask: false });
    editor().resetHistory(adj);
  });
}
function reset(platform = 'windows') {
  debouncedSetHistory.cancel(); debouncedSave.cancel();
  ipc.length = 0; tokens.length = 0; traces.length = 0; usageCalls = 0; cancelFailure = false; heldCancel = null;
  useSettingsStore.setState({ osPlatform: platform as any });
  useProcessStore.setState({ activeAiTasks: {} });
  select();
}
flushSync(() => root.render(<Host />));
reset();
const start = { x: 0, y: 0 }, end = { x: 1, y: 1 };
const definitions = [
  { name: 'replace', id: 'p', token: true, json: true, run: (h: any) => h.handleGenerativeReplace('p', 'test prompt', true) },
  { name: 'quick', id: 'p', token: true, json: true, run: (h: any) => h.handleQuickErase('ps', start, end) },
  { name: 'direct', id: 'p', token: false, json: true, run: (h: any) => h.handleDirectPatch('ps') },
  { name: 'subject', id: 's', run: (h: any) => h.handleGenerateAiMask('s', start, end) },
  { name: 'depth', id: 's', run: (h: any) => h.handleGenerateAiDepthMask('s', {}) },
  { name: 'foreground', id: 's', run: (h: any) => h.handleGenerateAiForegroundMask('s') },
  { name: 'sky', id: 's', run: (h: any) => h.handleGenerateAiSkyMask('s') },
  { name: 'text', id: 's', run: (h: any) => h.handleGenerateAiTextMask('s', 'thing') },
  { name: 'face', id: 's', run: (h: any) => h.handleGenerateAiFaceMask('s', ['skin']) },
];
async function reach(d: any, h = current!) {
  const tokenCount = tokens.length, ipcCount = ipc.length;
  const promise = d.run(h);
  if (d.token) { check(tokens.length === tokenCount + 1, 'token requested'); tokens[tokenCount].resolve('mock-token'); await tick(); }
  check(ipc.length === ipcCount + 1, `${d.name}: first IPC started`);
  if (d.name === 'quick') { ipc.at(-1).resolve({ maskDataBase64: 'mock-mask' }); await tick(); check(ipc.length === ipcCount + 2, 'quick second IPC started'); }
  return { promise, row: ipc.at(-1) };
}
const success = (d: any, tag = 'result') => d.json ? JSON.stringify({ [tag]: true }) : { maskDataBase64: tag };
async function test(name: string, action: () => Promise<void>) {
  const first = checks;
  try { await action(); results.push({ name, passed: true, assertions: checks - first, trace: structuredClone(traces) }); }
  catch (error: any) { results.push({ name, passed: false, assertions: checks - first, error: error.stack, trace: structuredClone(traces) }); throw error; }
  finally { debouncedSetHistory.cancel(); debouncedSave.cancel(); }
}
(window as any).runAiGuardTests = async () => {
  try {
    for (const failed of [false, true]) await test(`negative fixture pre-orphan: orphan cancel ${failed ? 'failure' : 'success'} loses recovery`, async () => {
      reset(); const orphan = adjustments(); orphan.aiPatches[0].isLoading = true; select('A', orphan);
      equal(Object.keys(tasks()), [], 'negative fixture starts without a task'); heldCancel = deferred();
      const promise = preOrphan!.handleCancelAiTask('p'); check(patch().isLoading, 'command still held');
      if (failed) heldCancel.reject(new Error('negative orphan cancel failure')); else heldCancel.resolve(null);
      await promise; check(patch().isLoading && busy(), 'pre-orphan fixture reproduces lost recovery');
    });
    for (const implementation of ['current', 'legacy']) await test(`${implementation}: orphan loading cancel reproduction`, async () => {
      reset(); const orphan = adjustments(); orphan.aiPatches[0].isLoading = true; select('A', orphan);
      equal(Object.keys(tasks()), [], 'orphan has no registered task'); check(busy(), 'orphan loading blocks tool');
      heldCancel = deferred(); const h = implementation === 'current' ? current! : legacy!;
      const promise = h.handleCancelAiTask('p'); check(patch().isLoading, 'held cancellation command has not settled');
      heldCancel.resolve(null); await promise;
      check(!patch().isLoading && !busy(), 'cancel recovers orphan loading');
      equal(patch().patchData, { original: true }, 'recovery changes no patch result');
    });
    for (const cancelId of ['p', 'ps']) await test(`orphan ${cancelId}: same-image recovery preserves all other patch fields`, async () => {
      reset(); const orphan = adjustments(); orphan.aiPatches[0].isLoading = true; select('A', orphan);
      const before = structuredClone(patch()); heldCancel = deferred(); const promise = current!.handleCancelAiTask(cancelId);
      check(patch().isLoading, 'still loading before acknowledgement'); heldCancel.resolve(null); await promise;
      equal(patch(), { ...before, isLoading: false }, 'only transient loading cleared'); equal(Object.keys(tasks()), [], 'no synthetic task created'); check(!busy(), 'tool recovers');
    });
    await test('orphan: rejected backend cancel retains legacy recovery behavior', async () => {
      reset(); const orphan = adjustments(); orphan.aiPatches[0].isLoading = true; select('A', orphan); cancelFailure = true;
      await current!.handleCancelAiTask('p'); check(!busy() && !patch().isLoading, 'legacy orphan recovery also runs on command rejection');
    });
    for (const returnToA of [false, true]) await test(`orphan: pending cancel cannot clear ${returnToA ? 'returned A' : 'new image B'}`, async () => {
      reset(); const orphan = adjustments(); orphan.aiPatches[0].isLoading = true; select('A', orphan); heldCancel = deferred();
      const promise = current!.handleCancelAiTask('p'); const b = adjustments(); b.aiPatches[0].isLoading = true; select('B', b);
      if (returnToA) { const a = adjustments(); a.aiPatches[0].isLoading = true; select('A', a); }
      const before = editor().adjustments; heldCancel.resolve(null); await promise;
      check(editor().adjustments === before, 'image generation prevents old recovery writes'); check(patch().isLoading, 'new image flag untouched');
    });
    await test('orphan: same-path metadata revision prevents stale fallback', async () => {
      reset(); const orphan = adjustments(); orphan.aiPatches[0].isLoading = true; select('A', orphan); heldCancel = deferred();
      const promise = current!.handleCancelAiTask('p'); const metadata = adjustments(); metadata.aiPatches[0].isLoading = true; metadata.aiPatches[0].prompt = 'fresh metadata';
      editor().resetHistory(metadata); const before = editor().adjustments; heldCancel.resolve(null); await promise;
      check(editor().adjustments === before && patch().isLoading, 'new metadata retains own transient state');
    });
    for (const cancelId of ['p', 'ps']) await test(`orphan ${cancelId}: new parent DirectPatch request wins pending cancel race`, async () => {
      reset(); const orphan = adjustments(); orphan.aiPatches[0].isLoading = true; select('A', orphan); heldCancel = deferred();
      const cancellation = current!.handleCancelAiTask(cancelId); const { promise, row } = await reach(definitions.find(d => d.name === 'direct')!, other!);
      const newTask = tasks().p; const before = editor().adjustments; heldCancel.resolve(null); await cancellation;
      check(tasks().p === newTask && busy(), 'new registration survives orphan fallback'); check(editor().adjustments === before && patch().isLoading, 'new request loading untouched');
      row.resolve('{"newManual":true}'); await promise; equal(patch().patchData, { newManual: true }, 'new result remains valid'); check(!busy(), 'new task settles normally');
    });
    await test('orphan: external slot replacement blocks stale unregister and loading cleanup', async () => {
      reset(); const orphan = adjustments(); orphan.aiPatches[0].isLoading = true; select('A', orphan);
      useProcessStore.getState().registerAiTask('p', 'legacy'); heldCancel = deferred(); const promise = current!.handleCancelAiTask('p');
      useProcessStore.getState().registerAiTask('p', 'external-new'); const replacement = tasks().p; const before = editor().adjustments;
      heldCancel.resolve(null); await promise; check(tasks().p === replacement, 'replacement slot retained'); check(editor().adjustments === before && patch().isLoading, 'replacement loading untouched');
    });
    await test('orphan: unchanged legacy slot is cleaned after acknowledgement', async () => {
      reset(); const orphan = adjustments(); orphan.aiPatches[0].isLoading = true; select('A', orphan);
      useProcessStore.getState().registerAiTask('p', 'legacy'); heldCancel = deferred(); const promise = current!.handleCancelAiTask('p');
      check(!!tasks().p, 'legacy slot retained before acknowledgement'); heldCancel.resolve(null); await promise; check(!busy() && !tasks().p, 'same captured legacy slot released');
    });
    await test('orphan: absent loading target is an adjustments/history no-op', async () => {
      reset(); const before = editor().adjustments; const history = editor().history; await current!.handleCancelAiTask('p');
      check(editor().adjustments === before && editor().history === history, 'no-op recovery does not create an edit');
    });
    for (const d of definitions.filter(d => d.token)) {
      await test(`${d.name}: token-await cancel across hook instances`, async () => {
        reset(); const promise = d.run(current); const task = tasks()[d.id];
        check(!!task && busy() && patch().isLoading, 'busy synchronously before token');
        await other!.handleCancelAiTask(d.id); check(tasks()[d.id] === task && busy(), 'cancel acknowledgement retains busy');
        tokens[0].resolve('mock-token'); await promise;
        equal(ipc.length, 0, 'cancelled token does not start IPC'); equal(Object.keys(tasks()), [], 'task cleaned'); check(!patch().isLoading && !busy(), 'loading cleaned');
      });
      await test(`${d.name}: token rejection cleanup`, async () => {
        reset(); const promise = d.run(current); check(busy(), 'busy before token rejection'); tokens[0].reject(new Error('mock token rejection')); await promise;
        equal(ipc.length, 0, 'no generation'); equal(Object.keys(tasks()), [], 'registration cleaned'); check(!patch().isLoading, 'loading cleaned');
      });
    }
    for (const d of definitions.filter(d => d.json)) {
      await test(`${d.name}: invalid JSON cleanup`, async () => {
        reset(); const { promise, row } = await reach(d); row.resolve('{broken'); await promise;
        equal(Object.keys(tasks()), [], 'registration cleaned'); check(!patch().isLoading, 'loading cleaned'); equal(patch().patchData, { original: true }, 'data preserved');
      });
    }
    for (const d of definitions) {
      await test(`${d.name}: cancelled late success cannot overwrite restored same-ID fields`, async () => {
        reset(); const { promise, row } = await reach(d); await other!.handleCancelAiTask(d.id);
        check(!!tasks()[d.id], 'original promise still busy');
        const restored = adjustments(); restored.aiPatches[0].patchData = { restored: true }; editor().setEditor({ adjustments: restored });
        // Deliberately restore the same IDs while the cancelled response is still held.
        row.resolve(success(d)); await promise;
        check(!busy(), 'busy released after original settled');
        equal(editor().adjustments, restored, 'restored fields stable');
        equal(patch().patchData, { restored: true }, 'late result not adopted');
        equal(editor().activeAiPatchContainerId, 'p', 'cancelled result did not deselect');
        if (!d.json) equal(editor().adjustments.masks[0].subMasks[0].parameters.old, 'original', 'mask not overwritten');
      });
      await test(`${d.name}: cross-image late success/finally leaves new image untouched`, async () => {
        reset(); const { promise, row } = await reach(d); const b = adjustments(); b.aiPatches[0].isLoading = true; select('B', b);
        const before = editor().adjustments; const index = editor().historyIndex; editor().patchesSentToBackend.add(d.id);
        row.resolve(success(d)); await promise;
        check(editor().adjustments === before, 'new image adjustments identity unchanged'); equal(editor().historyIndex, index, 'no new history');
        equal(editor().activeAiPatchContainerId, 'p', 'new image selection retained'); check(editor().patchesSentToBackend.has(d.id), 'new image backend marker retained');
        equal(Object.keys(tasks()), [], 'old registration released across path');
      });
      await test(`${d.name}: same-ID replacement keeps new task/loading/data`, async () => {
        reset(); const old = await reach(d); const newer = await reach(d, other!); const newTask = tasks()[d.id];
        const before = editor().adjustments; old.row.resolve(success(d, 'old')); await old.promise;
        check(tasks()[d.id] === newTask, 'old finally does not unregister replacement');
        check(editor().adjustments === before, 'old result/finally did not write');
        if (d.json) check(patch().isLoading, 'new loading retained');
        newer.row.resolve(success(d, 'new')); await newer.promise; equal(Object.keys(tasks()), [], 'new request settles');
        if (d.json) equal(patch().patchData, { new: true }, 'new result adopted');
        else equal(editor().adjustments.masks[0].subMasks[0].parameters.maskDataBase64, 'new', 'new mask adopted');
      });
      await test(`${d.name}: removed target drops result without history mutation`, async () => {
        reset(); const { promise, row } = await reach(d); const adj = { ...editor().adjustments, aiPatches: [], masks: [] }; editor().setEditor({ adjustments: adj });
        row.resolve(success(d)); await promise; check(editor().adjustments === adj, 'no write when target removed'); equal(Object.keys(tasks()), [], 'removed target registration cleaned');
      });
    }
    await test('quick: cancellation between phases suppresses second IPC', async () => {
      reset(); const promise = current!.handleQuickErase('ps', start, end); tokens[0].resolve('mock-token'); await tick(); equal(ipc.length, 1, 'first phase pending');
      await other!.handleCancelAiTask('p'); ipc[0].resolve({ maskDataBase64: 'late' }); await promise;
      equal(ipc.length, 1, 'no second phase'); check(!busy(), 'fully cleaned');
    });
    await test('quick: target removed between phases suppresses second IPC', async () => {
      reset(); const promise = current!.handleQuickErase('ps', start, end); tokens[0].resolve('mock-token'); await tick(); editor().setEditor({ adjustments: { ...editor().adjustments, aiPatches: [] } });
      ipc[0].resolve({ maskDataBase64: 'late' }); await promise; equal(ipc.length, 1, 'no second phase'); equal(Object.keys(tasks()), [], 'cleaned');
    });
    await test('replace: cancellation rejected by backend still invalidates late success', async () => {
      reset(); const d = definitions[0]; const { promise, row } = await reach(d); cancelFailure = true; await other!.handleCancelAiTask('p'); check(busy(), 'busy retained after cancel failure');
      row.resolve(success(d)); await promise; equal(patch().patchData, { original: true }, 'no adoption after failed cancellation command'); check(!busy(), 'released at original settlement');
    });
    await test('replace: late reject after image switch is a no-op', async () => {
      reset(); const { promise, row } = await reach(definitions[0]); select('B'); const before = editor().adjustments; row.reject(new Error('late failure')); await promise;
      check(editor().adjustments === before, 'new image not touched by catch/finally'); equal(editor().activeAiPatchContainerId, 'p', 'new selection retained');
    });
    await test('replace: A-B-A cannot revive an old request', async () => {
      reset(); const { promise, row } = await reach(definitions[0]); select('B'); select('A'); const before = editor().adjustments; row.resolve('{"late":true}'); await promise;
      check(editor().adjustments === before, 'old request remains invalid after return');
    });
    await test('replace: changing tool mode alone preserves valid generation', async () => {
      reset(); const { promise, row } = await reach(definitions[0]);
      // No mode state participates in the hook guards. The target/image remain valid.
      editor().setEditor({ toolSessionPanel: null }); row.resolve('{"applied":true}'); await promise; equal(patch().patchData, { applied: true }, 'result retained after mode exit');
    });
    for (const d of definitions.filter(d => d.token)) {
      for (const implementation of ['current', 'legacy']) await test(`Android ${implementation} ${d.name}: original token/cancel/late-success timing`, async () => {
        reset('android'); const h = implementation === 'current' ? current! : legacy!; const promise = d.run(h);
        equal(Object.keys(tasks()), [], 'Android token wait unregistered'); check(!patch().isLoading, 'Android token wait loading unchanged');
        tokens[0].resolve('mock-token'); await tick(); check(!!tasks().p, 'registered after token');
        if (d.name === 'quick') { ipc[0].resolve({ maskDataBase64: 'mock' }); await tick(); }
        await h.handleCancelAiTask('p'); equal(Object.keys(tasks()), [], 'Android cancel immediately unregisters'); check(!patch().isLoading, 'Android cancel immediately clears loading');
        ipc.at(-1).resolve('{"legacyLate":true}'); await promise; equal(patch().patchData, { legacyLate: true }, 'Android existing late adoption preserved');
      });
    }
    for (const d of definitions.filter(d => !d.token)) {
      for (const implementation of ['current', 'legacy']) await test(`Android ${implementation} ${d.name}: original completion and cancellation timing`, async () => {
        reset('android'); const h = implementation === 'current' ? current! : legacy!;
        const { promise, row } = await reach(d, h);
        if (d.name === 'direct') equal(Object.keys(tasks()), [], 'Android direct remains unregistered');
        if (d.name !== 'direct') {
          await h.handleCancelAiTask(d.id); equal(Object.keys(tasks()), [], 'Android shared cancellation immediately unregisters');
        }
        row.resolve(success(d, 'android')); await promise;
        if (d.json) equal(patch().patchData, { android: true }, 'Android direct result preserved');
        else equal(editor().adjustments.masks[0].subMasks[0].parameters.maskDataBase64, 'android', 'Android shared cancel retains legacy late adoption');
      });
    }
    for (const d of definitions) await test(`${d.name}: same-path metadata reset invalidates old response`, async () => {
      reset(); const { promise, row } = await reach(d); const metadata = adjustments();
      metadata.masks[0].subMasks[0].parameters = { parts: ['skin'], newMetadata: true };
      metadata.aiPatches[0].patchData = { newMetadata: true };
      const revision = editor().historyRevision; editor().resetHistory(metadata); check(editor().historyRevision > revision, 'metadata reset revision advances');
      row.resolve(success(d, 'stale')); await promise;
      check(editor().adjustments === metadata, 'metadata content retained without stale callback write'); equal(Object.keys(tasks()), [], 'stale registration released');
    });
    await test('negative control: pre-review hook overwrites same-path fresh metadata', async () => {
      reset(); const d = definitions.find(d => d.name === 'subject')!; const { promise, row } = await reach(d, preReview!);
      const metadata = adjustments(); metadata.masks[0].subMasks[0].parameters = { parts: ['skin'], newMetadata: true }; editor().resetHistory(metadata);
      row.resolve(success(d, 'stale')); await promise;
      check(!editor().adjustments.masks[0].subMasks[0].parameters.newMetadata, 'pre-review reproduces lost fresh parameter');
    });
    for (const timing of ['settle-in-B', 'settle-after-return-A']) {
      for (const implementation of ['current', 'pre-review']) await test(`${implementation}: A-B-A cache loading ${timing}`, async () => {
        reset(); const h = implementation === 'current' ? current! : preReview!;
        const { promise, row } = await reach(definitions[0], h);
        flushSync(() => editor().setEditor({ finalPreviewUrl: 'data:,cache' }));
        check(cacheRef.current?.adjustments.aiPatches[0].isLoading, 'real loader captures loading');
        globalImageCache.set('A', cacheRef.current); select('B'); const b = editor().adjustments;
        if (timing === 'settle-after-return-A') select('A', globalImageCache.get('A')!.adjustments);
        row.resolve('{"stale":true}'); await promise;
        if (timing === 'settle-in-B') { check(editor().adjustments === b, 'cleanup never writes image B'); select('A', globalImageCache.get('A')!.adjustments); }
        equal(Object.keys(tasks()), [], 'registration settled'); equal(patch().patchData, { original: true }, 'old result remains rejected');
        if (implementation === 'current') { check(!patch().isLoading && !busy(), 'owned loading cleared and returned image is not blocked'); check(!globalImageCache.get('A')!.adjustments.aiPatches[0].isLoading, 'cache loading cleared'); }
        else check(patch().isLoading && busy(), 'pre-review negative control reproduces orphan loading');
        globalImageCache.clear();
      });
    }
    for (const action of ['undo', 'goToHistoryIndex']) {
      for (const implementation of ['current', 'pre-review']) await test(`DirectPatch ${implementation}: ${action} busy survives history restoration`, async () => {
        reset(); useUIStore.getState().setUI({ activePanel: 'ai' as any }); editor().beginToolSession('ai' as any);
        const edited = adjustments(); edited.aiPatches[0].patchData = { historyEdit: true };
        editor().setEditor({ adjustments: edited }); editor().pushHistory(edited);
        const h = implementation === 'current' ? current! : preReview!;
        const { promise, row } = await reach(definitions.find(d => d.name === 'direct')!, h);
        editor().pushHistory(structuredClone(editor().adjustments));
        if (action === 'undo') editor().undo(); else editor().goToHistoryIndex(1);
        check(!patch().isLoading, 'history restores loading flag to false');
        if (implementation === 'current') {
          equal(tasks().p?.type, 'manual-patch', 'desktop direct has local manual task'); check(busy(), 'task registration retains busy independent of history');
          const before = editor().adjustments; cancelToolSession(); check(editor().adjustments === before, 'tool Cancel blocked during direct request');
          equal(useUIStore.getState().activePanel, 'ai', 'mode remains while busy');
          await other!.handleCancelAiTask('p'); check(busy(), 'cancel acknowledgement still waits for original direct Promise');
          row.resolve('{"lateManual":true}'); await promise;
          equal(patch().patchData, { historyEdit: true }, 'cancelled direct callback cannot overwrite restored history'); check(!busy(), 'direct task cleans up after settlement');
        } else {
          check(!busy(), 'negative control exposes tool Cancel'); cancelToolSession(); equal(patch().patchData, { original: true }, 'negative control tool Cancel restores snapshot');
          row.resolve('{"lateManual":true}'); await promise; equal(patch().patchData, { lateManual: true }, 'negative control reproduces late overwrite');
        }
        useUIStore.getState().setPanel('adjustments' as any);
      });
    }
    await test('core-owner integration: returned-while-pending snapshot strips transient loading', async () => {
      reset(); useUIStore.getState().setUI({ activePanel: 'ai' as any }); editor().beginToolSession('ai' as any);
      const { promise, row } = await reach(definitions[0]); flushSync(() => editor().setEditor({ finalPreviewUrl: 'data:,snapshot' }));
      globalImageCache.set('A', cacheRef.current); select('B'); select('A', globalImageCache.get('A')!.adjustments);
      check(!editor().aiSessionSnapshot?.aiPatches[0].isLoading, 'core snapshot strips cached transient loading');
      row.resolve('{"stale":true}'); await promise; check(!busy(), 'request cleanup releases busy');
      cancelToolSession(); check(!busy() && !Object.keys(tasks()).length, 'core Cancel no longer restores transient loading');
      globalImageCache.clear(); useUIStore.getState().setPanel('adjustments' as any);
    });
    reset();
    return { passed: true, cases: results.length, assertions: checks, results, limitations: ['Native IPC and token boundaries are explicit deferred mocks; real hook, React, stores, actions, loader and cache are used.', 'No Windows, AI algorithm, image decoding, real credentials or Rust metadata serialization exercised. Cache observation concerns frontend objects only.'] };
  } catch (error: any) { return { passed: false, cases: results.length, assertions: checks, results, error: error.stack }; }
  finally { debouncedSetHistory.cancel(); debouncedSave.cancel(); flushSync(() => root.unmount()); }
};
