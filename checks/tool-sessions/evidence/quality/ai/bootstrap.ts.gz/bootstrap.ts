import { mockWindows, mockIPC } from '@tauri-apps/api/mocks';
mockWindows('main');
window.__TAURI_OS_PLUGIN_INTERNALS__ = { platform: 'windows', eol: '\n', os_type: 'linux', family: 'unix', version: 'mock', arch: 'x86_64', exe_extension: '' };
mockIPC((cmd) => { if (cmd === 'list_luts') return []; return null; }, { shouldMockEvents: true });
await import('./fixture.tsx');
